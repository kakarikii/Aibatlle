import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for getting game statistics
  app.get('/api/stats', async (req, res) => {
    try {
      // In a real implementation, we would fetch stats from a database
      // For now, we'll return mock stats
      res.json({
        totalGames: 50,
        tWins: 23,
        ctWins: 27,
        mostPlayedMap: "dust2",
        averageRoundTime: 78.5
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch game statistics" });
    }
  });

  // API route for saving game results
  app.post('/api/game/result', async (req, res) => {
    try {
      const { tScore, ctScore, rounds, duration } = req.body;
      
      // Validate the input
      if (typeof tScore !== 'number' || typeof ctScore !== 'number') {
        return res.status(400).json({ message: "Invalid score values" });
      }
      
      // In a real implementation, we would save this to a database
      console.log(`Game finished: T ${tScore} - ${ctScore} CT`);
      
      res.json({ success: true, message: "Game result saved successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to save game result" });
    }
  });

  // API route for AI agent data
  app.get('/api/agents', async (req, res) => {
    try {
      // In a real implementation, we would fetch agent data from a database
      res.json({
        agents: [
          { id: "t-0", team: "T", winRate: 0.52, kd: 1.2, role: "entry" },
          { id: "t-1", team: "T", winRate: 0.48, kd: 0.9, role: "support" },
          { id: "t-2", team: "T", winRate: 0.55, kd: 1.1, role: "lurk" },
          { id: "t-3", team: "T", winRate: 0.50, kd: 1.0, role: "awp" },
          { id: "t-4", team: "T", winRate: 0.51, kd: 1.0, role: "igl" },
          { id: "ct-0", team: "CT", winRate: 0.53, kd: 1.3, role: "entry" },
          { id: "ct-1", team: "CT", winRate: 0.49, kd: 0.95, role: "support" },
          { id: "ct-2", team: "CT", winRate: 0.54, kd: 1.2, role: "lurk" },
          { id: "ct-3", team: "CT", winRate: 0.51, kd: 1.1, role: "awp" },
          { id: "ct-4", team: "CT", winRate: 0.52, kd: 1.05, role: "igl" }
        ]
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch agent data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
