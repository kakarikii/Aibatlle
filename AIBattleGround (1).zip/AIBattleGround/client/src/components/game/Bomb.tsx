import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useRef, useState, useEffect } from "react";
import { Box, Text } from "@react-three/drei";
import { useRoundState } from "../../lib/stores/useRoundState";
import { useAudio } from "../../lib/stores/useAudio";

interface BombProps {
  position: THREE.Vector3;
  isPlanted: boolean;
}

const Bomb = ({ position, isPlanted }: BombProps) => {
  const bombRef = useRef<THREE.Group>(null);
  const { roundState, bombTimer, setBombTimer, endRound, incrementTWins } = useRoundState();
  const { playSuccessSound } = useAudio();
  const [blinkColor, setBlinkColor] = useState(new THREE.Color(0xff0000));
  const [blinkRate, setBlinkRate] = useState(1); // Blinks per second
  
  // Start bomb timer when planted
  useEffect(() => {
    if (isPlanted) {
      setBombTimer(40); // 40 seconds timer for bomb
    }
  }, [isPlanted, setBombTimer]);
  
  // Handle bomb timer and explosion
  useFrame((state, delta) => {
    if (bombRef.current) {
      bombRef.current.position.copy(position);
      
      // Handle bomb blinking when planted
      if (isPlanted && roundState === 'active') {
        // Decrease timer
        setBombTimer(prev => Math.max(0, prev - delta));
        
        // Increase blink rate as timer gets lower
        if (bombTimer < 10) {
          setBlinkRate(5);
        } else if (bombTimer < 20) {
          setBlinkRate(3);
        } else {
          setBlinkRate(1);
        }
        
        // Blink effect - toggle between red and black
        if (Math.sin(state.clock.elapsedTime * Math.PI * blinkRate) > 0) {
          setBlinkColor(new THREE.Color(0xff0000));
        } else {
          setBlinkColor(new THREE.Color(0x000000));
        }
        
        // Bomb explosion
        if (bombTimer <= 0) {
          // Play explosion sound
          playSuccessSound();
          
          // T team wins because bomb exploded
          endRound('T');
          incrementTWins();
        }
      }
    }
  });
  
  return (
    <group ref={bombRef} position={position}>
      {/* Bomb body */}
      <Box 
        args={[0.8, 0.4, 0.6]} 
        position={[0, 0, 0]}
        castShadow
        receiveShadow
      >
        <meshStandardMaterial color="#222222" />
      </Box>
      
      {/* Blinking light */}
      {isPlanted && (
        <Box
          args={[0.2, 0.1, 0.2]}
          position={[0, 0.3, 0]}
        >
          <meshBasicMaterial color={blinkColor} />
        </Box>
      )}
      
      {/* Timer display */}
      {isPlanted && (
        <Text
          position={[0, 0.8, 0]}
          fontSize={0.5}
          color="#ff0000"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.05}
          outlineColor="#000000"
        >
          {bombTimer.toFixed(1)}
        </Text>
      )}
    </group>
  );
};

export default Bomb;
