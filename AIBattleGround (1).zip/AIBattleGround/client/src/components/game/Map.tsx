import { useTexture, Text } from "@react-three/drei";
import * as THREE from "three";
import { useMemo } from "react";
import { mapData } from "../../lib/game/mapData";

const Map = () => {
  // Load textures
  const sandTexture = useTexture("/textures/sand.jpg");
  const woodTexture = useTexture("/textures/wood.jpg");
  
  // Make textures repeat properly
  useMemo(() => {
    [sandTexture, woodTexture].forEach(texture => {
      texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
      texture.repeat.set(10, 10);
    });
  }, [sandTexture, woodTexture]);
  
  return (
    <group>
      {/* Ground */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]} 
        receiveShadow
      >
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial map={sandTexture} />
      </mesh>
      
      {/* Walls and structures based on map data */}
      {mapData.walls.map((wall, index) => (
        <mesh
          key={`wall-${index}`}
          position={[wall.position.x, wall.position.y, wall.position.z]}
          scale={[wall.size.width, wall.size.height, wall.size.depth]}
          castShadow
          receiveShadow
        >
          <boxGeometry />
          <meshStandardMaterial map={woodTexture} />
        </mesh>
      ))}
      
      {/* Bomb sites */}
      {mapData.bombSites.map((site, index) => (
        <group key={`bombsite-${index}`}>
          {/* Bomb site floor marker */}
          <mesh
            position={[site.position.x, 0.01, site.position.z]}
            rotation={[-Math.PI / 2, 0, 0]}
            receiveShadow
          >
            <planeGeometry args={[site.size.width, site.size.depth]} />
            <meshStandardMaterial color={site.name === "A" ? "#ff6b6b" : "#5c7cfa"} transparent opacity={0.7} />
          </mesh>
          
          {/* Bomb site label - using Text from drei instead of textGeometry */}
          <Text
            position={[site.position.x, 1, site.position.z]}
            fontSize={2}
            color="white"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0.05}
            outlineColor="#000000"
          >
            {site.name}
          </Text>
        </group>
      ))}
      
      {/* Spawn points are invisible but we can visualize them during development */}
      {mapData.spawnPoints.map((spawn, index) => (
        <mesh
          key={`spawn-${index}`}
          position={[spawn.position.x, 0.1, spawn.position.z]}
          rotation={[-Math.PI / 2, 0, 0]}
        >
          <planeGeometry args={[3, 3]} />
          <meshBasicMaterial 
            color={spawn.team === "T" ? "#ffa94d" : "#4dabff"} 
            transparent 
            opacity={0.5} 
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
};

export default Map;
