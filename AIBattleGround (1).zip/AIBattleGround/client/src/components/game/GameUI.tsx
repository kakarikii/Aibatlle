import { useEffect, useMemo, useState } from "react";
import { useKeyboardControls } from "@react-three/drei";
import { useAudio } from "../../lib/stores/useAudio";
import { useGameState } from "../../lib/stores/useGameState";
import { useRoundState } from "../../lib/stores/useRoundState";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Card } from "../ui/card";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";

const GameUI = () => {
  const { toggleMute, isMuted } = useAudio();
  const { players, bullets } = useGameState();
  const { 
    roundState, 
    roundNumber, 
    startNewRound, 
    roundTimer, 
    bombPlanted,
    bombTimer,
    tWins,
    ctWins
  } = useRoundState();
  
  // Count alive players per team
  const teamStats = useMemo(() => {
    const tAlive = players.filter(p => p.team === 'T' && p.isAlive).length;
    const ctAlive = players.filter(p => p.team === 'CT' && p.isAlive).length;
    const tTotal = players.filter(p => p.team === 'T').length;
    const ctTotal = players.filter(p => p.team === 'CT').length;
    
    return { tAlive, ctAlive, tTotal, ctTotal };
  }, [players]);
  
  // Round timer display
  const formattedTime = useMemo(() => {
    const minutes = Math.floor(roundTimer / 60);
    const seconds = Math.floor(roundTimer % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }, [roundTimer]);
  
  // Winner message
  const [winnerMessage, setWinnerMessage] = useState("");
  
  useEffect(() => {
    if (roundState === 'ended') {
      setWinnerMessage(
        tWins > ctWins ? "Terrorists are leading!" : 
        ctWins > tWins ? "Counter-Terrorists are leading!" : 
        "Score is tied!"
      );
    } else {
      setWinnerMessage("");
    }
  }, [roundState, tWins, ctWins]);
  
  return (
    <div className="fixed inset-0 pointer-events-none">
      {/* Top HUD - Round info */}
      <div className="p-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="bg-yellow-500 text-white py-1 px-3">
            T: {tWins}
          </Badge>
          
          <Card className="p-2 bg-gray-800 text-white">
            Round {roundNumber}/30 
            <span className="ml-2 text-yellow-500">
              {roundState === 'active' ? formattedTime : roundState === 'ended' ? 'Ended' : 'Starting...'}
            </span>
          </Card>
          
          <Badge variant="outline" className="bg-blue-500 text-white py-1 px-3">
            CT: {ctWins}
          </Badge>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button 
            onClick={toggleMute} 
            className="pointer-events-auto" 
            variant="outline"
            size="sm"
          >
            {isMuted ? "🔇 Unmute" : "🔊 Mute"}
          </Button>
          
          {roundState === 'ended' && (
            <Button 
              onClick={startNewRound} 
              className="pointer-events-auto bg-green-600 hover:bg-green-700 text-white"
              size="sm"
            >
              Next Round
            </Button>
          )}
        </div>
      </div>
      
      {/* Team status */}
      <div className="fixed left-4 top-20">
        <Card className="p-3 bg-gray-800 text-white">
          <div className="flex flex-col space-y-2 w-40">
            <div>
              <div className="flex justify-between">
                <span className="text-yellow-500">Terrorists</span>
                <span>{teamStats.tAlive}/{teamStats.tTotal}</span>
              </div>
              <Progress value={(teamStats.tAlive / teamStats.tTotal) * 100} className="h-2 bg-gray-700"  />
            </div>
            
            <Separator className="bg-gray-600" />
            
            <div>
              <div className="flex justify-between">
                <span className="text-blue-500">Counter-T</span>
                <span>{teamStats.ctAlive}/{teamStats.ctTotal}</span>
              </div>
              <Progress value={(teamStats.ctAlive / teamStats.ctTotal) * 100} className="h-2 bg-gray-700" />
            </div>
          </div>
        </Card>
      </div>
      
      {/* Bomb status */}
      {bombPlanted && (
        <div className="fixed right-4 top-20">
          <Card className="p-3 bg-gray-800 text-white">
            <div className="flex items-center space-x-4">
              <span className="text-red-500 font-bold">BOMB</span>
              <div className="w-32">
                <Progress 
                  value={(bombTimer / 40) * 100} 
                  className="h-2 bg-gray-700" 
                />
              </div>
              <span>{bombTimer.toFixed(1)}s</span>
            </div>
          </Card>
        </div>
      )}
      
      {/* Round end message */}
      {roundState === 'ended' && (
        <div className="fixed inset-0 flex items-center justify-center">
          <Card className="p-6 bg-gray-800 text-white text-center">
            <h2 className="text-2xl font-bold mb-2">Round Ended</h2>
            <p className="text-xl">{winnerMessage}</p>
            <p className="mt-4 text-sm text-gray-400">Score: T {tWins} - {ctWins} CT</p>
          </Card>
        </div>
      )}
      
      {/* Debug information */}
      <div className="fixed bottom-4 left-4 text-xs text-white bg-black bg-opacity-50 p-2 rounded">
        Players: {players.length} | Active Bullets: {bullets.length}
      </div>
    </div>
  );
};

export default GameUI;
