import { useRef } from "react";
import * as THREE from "three";
import { Box } from "@react-three/drei";

interface WeaponProps {
  type: string;
  position: THREE.Vector3;
}

const Weapon = ({ type, position }: WeaponProps) => {
  const weaponRef = useRef<THREE.Group>(null);
  
  // Colors for different weapon types
  const getWeaponColor = () => {
    switch(type) {
      case 'rifle':
        return 0x333333;
      case 'pistol':
        return 0x666666;
      case 'sniper':
        return 0x222222;
      default:
        return 0x444444;
    }
  };
  
  // Get weapon dimensions based on type
  const getDimensions = () => {
    switch(type) {
      case 'rifle':
        return { length: 1.5, width: 0.1, height: 0.2 };
      case 'pistol':
        return { length: 0.6, width: 0.1, height: 0.2 };
      case 'sniper':
        return { length: 1.8, width: 0.1, height: 0.2 };
      default:
        return { length: 1.0, width: 0.1, height: 0.2 };
    }
  };
  
  const dimensions = getDimensions();
  
  return (
    <group ref={weaponRef} position={position}>
      {/* Main weapon body */}
      <Box
        args={[dimensions.length, dimensions.height, dimensions.width]}
        position={[dimensions.length / 2, 0, 0]}
        castShadow
      >
        <meshStandardMaterial color={getWeaponColor()} />
      </Box>
      
      {/* Weapon grip/handle */}
      {type !== 'pistol' && (
        <Box
          args={[0.2, 0.4, 0.1]}
          position={[0.2, -0.2, 0]}
          castShadow
        >
          <meshStandardMaterial color={getWeaponColor()} />
        </Box>
      )}
      
      {/* Weapon sight (for rifle and sniper) */}
      {(type === 'rifle' || type === 'sniper') && (
        <Box
          args={[0.1, 0.1, 0.1]}
          position={[0.5, 0.2, 0]}
          castShadow
        >
          <meshStandardMaterial color={0x111111} />
        </Box>
      )}
      
      {/* Sniper scope */}
      {type === 'sniper' && (
        <Box
          args={[0.4, 0.15, 0.15]}
          position={[0.8, 0.3, 0]}
          castShadow
        >
          <meshStandardMaterial color={0x111111} />
        </Box>
      )}
    </group>
  );
};

export default Weapon;
