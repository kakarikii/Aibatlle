import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import { OrbitControls, Stats } from "@react-three/drei";
import * as THREE from "three";
import Map from "./Map";
import Player from "./Player";
import Bomb from "./Bomb";
import Bullet from "./Bullet";
import { useGameState } from "../../lib/stores/useGameState";
import { useRoundState } from "../../lib/stores/useRoundState";
import { checkCollisions } from "../../lib/physics/collision";
import { useAudio } from "../../lib/stores/useAudio";
import { setupAIAgents, updateAIAgents } from "../../lib/ai/agent";

const Arena = () => {
  const { scene } = useThree();
  const controlsRef = useRef<any>(null);
  const { 
    players, 
    bullets, 
    addPlayer, 
    removePlayer, 
    updatePlayer, 
    removeBullet, 
    resetGameState 
  } = useGameState();
  const { 
    roundState, 
    roundNumber, 
    startNewRound, 
    endRound, 
    bombPlanted, 
    setBombPlanted,
    bombDefused,
    setBombDefused,
    tWins,
    ctWins,
    incrementTWins,
    incrementCTWins
  } = useRoundState();
  const { playHit } = useAudio();
  
  // Setup a light for the scene
  useEffect(() => {
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(20, 30, 10);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    directionalLight.shadow.camera.near = 0.5;
    directionalLight.shadow.camera.far = 100;
    directionalLight.shadow.camera.left = -50;
    directionalLight.shadow.camera.right = 50;
    directionalLight.shadow.camera.top = 50;
    directionalLight.shadow.camera.bottom = -50;
    scene.add(directionalLight);
    
    return () => {
      scene.remove(ambientLight);
      scene.remove(directionalLight);
    };
  }, [scene]);
  
  // Initialize players
  useEffect(() => {
    // Set up 5v5 match with 10 AI players
    resetGameState();
    
    // Create 5 Terrorist players - spaced out in spawn area to prevent clipping
    for (let i = 0; i < 5; i++) {
      // Use a circle pattern to prevent multiple players spawning on the same spot
      const angle = (i / 5) * Math.PI * 2;
      const distance = 4; // Radius from spawn center
      
      addPlayer({
        id: `t-${i}`,
        position: new THREE.Vector3(
          -30 + Math.cos(angle) * distance, 
          1, 
          -30 + Math.sin(angle) * distance
        ),
        rotation: Math.random() * Math.PI * 2, // Random initial look direction
        health: 100,
        team: 'T',
        weapon: i % 3 === 0 ? 'sniper' : (i % 2 === 0 ? 'rifle' : 'pistol'),
        isAI: true,
        isAlive: true,
        isDefusing: false,
        isPlanting: false
      });
    }
    
    // Create 5 Counter-Terrorist players - circular spawn to prevent clipping
    for (let i = 0; i < 5; i++) {
      // Use a circle pattern to prevent multiple players spawning on the same spot
      const angle = (i / 5) * Math.PI * 2;
      const distance = 4; // Radius from spawn center
      
      addPlayer({
        id: `ct-${i}`,
        position: new THREE.Vector3(
          20 + Math.cos(angle) * distance, 
          1, 
          20 + Math.sin(angle) * distance
        ),
        rotation: Math.random() * Math.PI * 2, // Random initial look direction
        health: 100,
        team: 'CT',
        weapon: i % 3 === 0 ? 'sniper' : (i % 2 === 0 ? 'rifle' : 'pistol'),
        isAI: true,
        isAlive: true,
        isDefusing: false,
        isPlanting: false
      });
    }
    
    // Initialize AI agents
    setupAIAgents();
    
    // Start the first round
    startNewRound();
    
    console.log("Players initialized");
    
  }, [addPlayer, resetGameState, startNewRound]);
  
  // Game loop
  useFrame((state, delta) => {
    // Get the latest round state
    const currentRoundState = useRoundState.getState();
    
    // Update round timer
    if (currentRoundState.roundState === 'active') {
      // Update timer
      currentRoundState.setRoundTimer(Math.max(0, currentRoundState.roundTimer - delta));
      
      // Check if time expired
      if (currentRoundState.roundTimer <= 0 && !currentRoundState.bombPlanted) {
        // Time expired without bomb plant, CT win
        currentRoundState.endRound('CT');
        currentRoundState.incrementCTWins();
        console.log("Round ended: Time expired, CT win");
      }
      
      // Update AI agents - faster movement
      updateAIAgents(delta);
    }
    
    // Process bullet collisions
    checkCollisions(players, bullets, (playerId, bulletId) => {
      // Get the player and bullet involved
      const player = players.find(p => p.id === playerId);
      const bullet = bullets.find(b => b.id === bulletId);
      
      if (player && bullet) {
        // Apply damage to the player
        const damage = bullet.weapon === 'rifle' ? 25 : 50;
        const newHealth = Math.max(0, player.health - damage);
        
        // Play hit sound
        playHit();
        
        // Update player's health
        updatePlayer(playerId, { health: newHealth });
        
        // If player's health reached 0, mark as dead
        if (newHealth <= 0) {
          updatePlayer(playerId, { isAlive: false });
          console.log(`Player ${playerId} eliminated`);
          
          // Check if all players in a team are dead
          const teamT = players.filter(p => p.team === 'T' && p.isAlive);
          const teamCT = players.filter(p => p.team === 'CT' && p.isAlive);
          
          if (teamT.length === 0) {
            // CT team wins the round
            currentRoundState.endRound('CT');
            currentRoundState.incrementCTWins();
            console.log("Round ended: All Terrorists eliminated, CT win");
          } else if (teamCT.length === 0 && !currentRoundState.bombPlanted) {
            // T team wins the round (all CTs eliminated)
            currentRoundState.endRound('T');
            currentRoundState.incrementTWins();
            console.log("Round ended: All CTs eliminated, T win");
          }
        }
        
        // Remove the bullet that hit
        removeBullet(bulletId);
      }
    });
    
    // Handle round timer for bomb
    if (currentRoundState.bombPlanted) {
      // Update bomb timer
      currentRoundState.setBombTimer(Math.max(0, currentRoundState.bombTimer - delta));
      
      // Check if bomb exploded
      if (currentRoundState.bombTimer <= 0) {
        currentRoundState.endRound('T');
        currentRoundState.incrementTWins();
        currentRoundState.setBombPlanted(false);
        console.log("Round ended: Bomb exploded, T win");
      }
      
      // Check for CT win by defusing
      if (currentRoundState.bombDefused) {
        currentRoundState.endRound('CT');
        currentRoundState.incrementCTWins();
        currentRoundState.setBombPlanted(false);
        currentRoundState.setBombDefused(false);
        console.log("Round ended: Bomb defused, CT win");
      }
    }
  });
  
  return (
    <>
      {/* Debug Statistics */}
      <Stats />
      
      {/* Camera Controls */}
      <OrbitControls 
        ref={controlsRef} 
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        minDistance={10}
        maxDistance={100}
        maxPolarAngle={Math.PI / 2 - 0.1}
      />
      
      {/* Game Map */}
      <Map />
      
      {/* Players */}
      {players.map((player) => (
        <Player key={player.id} {...player} />
      ))}
      
      {/* Bomb */}
      <Bomb position={bombPlanted ? new THREE.Vector3(0, 0.5, 0) : new THREE.Vector3(0, -10, 0)} isPlanted={bombPlanted} />
      
      {/* Bullets */}
      {bullets.map((bullet) => (
        <Bullet 
          key={bullet.id}
          id={bullet.id}
          position={bullet.position}
          velocity={bullet.velocity}
          weapon={bullet.weapon}
        />
      ))}
    </>
  );
};

export default Arena;
