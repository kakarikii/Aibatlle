import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useRef, useState } from "react";
import { Box, Text } from "@react-three/drei";
import { useGameState } from "../../lib/stores/useGameState";
import Weapon from "./Weapon";

interface PlayerProps {
  id: string;
  position: THREE.Vector3;
  rotation: number;
  health: number;
  team: 'T' | 'CT';
  weapon: string;
  isAI: boolean;
  isAlive: boolean;
  isDefusing: boolean;
  isPlanting: boolean;
}

const Player = ({
  id,
  position,
  rotation,
  health,
  team,
  weapon,
  isAI,
  isAlive,
  isDefusing,
  isPlanting
}: PlayerProps) => {
  const playerRef = useRef<THREE.Group>(null);
  const { updatePlayer } = useGameState();
  const [playerColor] = useState(() => team === 'T' ? new THREE.Color(0xf5a742) : new THREE.Color(0x5271ff));
  
  // Update player position and rotation
  useFrame(() => {
    if (playerRef.current && isAlive) {
      playerRef.current.position.copy(position);
      playerRef.current.rotation.y = rotation;
    }
  });
  
  if (!isAlive) {
    return null;
  }
  
  return (
    <group ref={playerRef} position={position}>
      {/* Player body */}
      <Box 
        args={[1, 2, 1]} 
        position={[0, 1, 0]}
        castShadow
        receiveShadow
      >
        <meshStandardMaterial color={playerColor} />
      </Box>
      
      {/* Player head */}
      <Box
        args={[0.6, 0.6, 0.6]}
        position={[0, 2.5, 0]}
        castShadow
      >
        <meshStandardMaterial color={playerColor.clone().multiplyScalar(1.2)} />
      </Box>
      
      {/* Health bar */}
      <Box
        args={[1, 0.1, 0.1]}
        position={[0, 3.2, 0]}
        scale={[health / 100, 1, 1]}
      >
        <meshBasicMaterial color={health > 50 ? 0x00ff00 : health > 20 ? 0xffff00 : 0xff0000} />
      </Box>
      
      {/* Player label */}
      <Text
        position={[0, 3.5, 0]}
        fontSize={0.5}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.05}
        outlineColor="#000000"
      >
        {`${team}-${id.split('-')[1]} (${health})`}
      </Text>
      
      {/* Player's weapon */}
      <Weapon 
        type={weapon} 
        position={new THREE.Vector3(0.5, 1.5, 0.5)} 
      />
      
      {/* Show planting/defusing status */}
      {isPlanting && (
        <Text
          position={[0, 4, 0]}
          fontSize={0.4}
          color="#ff0000"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.05}
          outlineColor="#000000"
        >
          PLANTING
        </Text>
      )}
      
      {isDefusing && (
        <Text
          position={[0, 4, 0]}
          fontSize={0.4}
          color="#00ff00"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.05}
          outlineColor="#000000"
        >
          DEFUSING
        </Text>
      )}
    </group>
  );
};

export default Player;
