import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useRef } from "react";
import { useGameState } from "../../lib/stores/useGameState";

interface BulletProps {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  weapon: string;
}

const Bullet = ({ id, position, velocity, weapon }: BulletProps) => {
  const bulletRef = useRef<THREE.Mesh>(null);
  const { updateBullet, removeBullet } = useGameState();
  
  // Set bullet color and size based on weapon type
  const bulletColor = weapon === 'rifle' ? 0xffff00 : 0xff0000;
  const bulletSize = weapon === 'rifle' ? 0.05 : 0.08;
  
  // Bullet lifespan counter
  const lifespanRef = useRef(3); // 3 seconds max lifespan
  
  // Update bullet position based on velocity
  useFrame((state, delta) => {
    if (bulletRef.current) {
      // Move bullet
      const newPosition = position.clone().add(velocity.clone().multiplyScalar(delta * 50));
      
      // Update bullet position
      bulletRef.current.position.copy(newPosition);
      updateBullet(id, { position: newPosition });
      
      // Reduce lifespan
      lifespanRef.current -= delta;
      
      // Remove bullet if it goes too far or exceeds lifespan
      if (
        newPosition.x < -50 || 
        newPosition.x > 50 || 
        newPosition.z < -50 || 
        newPosition.z > 50 ||
        newPosition.y < 0 ||
        newPosition.y > 20 ||
        lifespanRef.current <= 0
      ) {
        removeBullet(id);
      }
    }
  });
  
  return (
    <mesh ref={bulletRef} position={position}>
      <sphereGeometry args={[bulletSize, 8, 8]} />
      <meshBasicMaterial color={bulletColor} />
    </mesh>
  );
};

export default Bullet;
