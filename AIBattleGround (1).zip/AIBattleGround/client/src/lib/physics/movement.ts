import * as THREE from "three";
import { checkWallCollision } from "./collision";
import { mapData } from "../game/mapData";
import { GAME_CONSTANTS } from "../game/constants";

/**
 * Calculate a new position based on input and current position
 */
export function calculateMovement(
  currentPosition: THREE.Vector3,
  direction: THREE.Vector3,
  rotation: number,
  speed: number,
  delta: number
): THREE.Vector3 {
  // Calculate the movement vector in world space
  const moveX = direction.x * speed * delta;
  const moveZ = direction.z * speed * delta;
  
  // Apply rotation to movement
  const rotatedMoveX = moveX * Math.cos(rotation) - moveZ * Math.sin(rotation);
  const rotatedMoveZ = moveX * Math.sin(rotation) + moveZ * Math.cos(rotation);
  
  // Calculate new position
  const newPosition = currentPosition.clone();
  newPosition.x += rotatedMoveX;
  newPosition.z += rotatedMoveZ;
  
  // Check collision with walls
  if (checkWallCollision(newPosition, mapData.walls)) {
    // Collision detected, don't update position
    return currentPosition;
  }
  
  // Ensure the player stays within map bounds
  newPosition.x = Math.max(-50, Math.min(50, newPosition.x));
  newPosition.z = Math.max(-50, Math.min(50, newPosition.z));
  
  return newPosition;
}

/**
 * Calculate the direction vector for AI movement
 */
export function calculateAIMovementDirection(
  from: THREE.Vector3,
  to: THREE.Vector3
): THREE.Vector3 {
  // Get direction vector
  const direction = to.clone().sub(from).normalize();
  
  // Keep y at 0 to keep movement on the ground
  direction.y = 0;
  
  return direction;
}

/**
 * Calculate rotation to face a target position
 */
export function calculateRotationToTarget(
  currentPosition: THREE.Vector3,
  targetPosition: THREE.Vector3
): number {
  // Calculate direction vector
  const directionVector = targetPosition.clone().sub(currentPosition);
  
  // Calculate the angle
  return Math.atan2(directionVector.x, directionVector.z);
}

/**
 * Generate random valid position on the map (for respawning)
 */
export function generateRandomPosition(team: 'T' | 'CT'): THREE.Vector3 {
  // Get team spawn positions
  const teamSpawns = mapData.spawnPoints.filter(spawn => spawn.team === team);
  
  // If no spawn points defined, use default positions
  if (teamSpawns.length === 0) {
    if (team === 'T') {
      return new THREE.Vector3(-20, 1, -20);
    } else {
      return new THREE.Vector3(20, 1, -20);
    }
  }
  
  // Pick a random spawn point
  const randomSpawnIndex = Math.floor(Math.random() * teamSpawns.length);
  const spawn = teamSpawns[randomSpawnIndex];
  
  // Add some randomness within the spawn area
  const randomOffset = new THREE.Vector3(
    (Math.random() - 0.5) * 4,
    0,
    (Math.random() - 0.5) * 4
  );
  
  return new THREE.Vector3(
    spawn.position.x + randomOffset.x,
    1, // Height above ground
    spawn.position.z + randomOffset.z
  );
}
