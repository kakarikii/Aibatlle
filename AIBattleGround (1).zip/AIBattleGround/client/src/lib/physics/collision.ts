import * as THREE from "three";
import { Player, Bullet } from "../stores/useGameState";

// Collision detection for bullets and players
export function checkCollisions(
  players: Player[],
  bullets: Bullet[],
  onHit: (playerId: string, bulletId: string) => void
) {
  // Only check collisions for alive players
  const alivePlayers = players.filter(player => player.isAlive);
  
  // Check each bullet against each player
  bullets.forEach(bullet => {
    const bulletPosition = bullet.position;
    
    // In a real implementation, we'd use a spatial partitioning system for efficiency
    alivePlayers.forEach(player => {
      // Skip collision check if bullet is from the same team
      const bulletFromPlayer = bullet.id.split('-')[1];
      const bulletPlayerObj = players.find(p => p.id === bulletFromPlayer);
      
      if (bulletPlayerObj && bulletPlayerObj.team === player.team) {
        return; // Skip friendly fire
      }
      
      // Simple collision detection using distance (spherical collision)
      const distance = bulletPosition.distanceTo(player.position);
      
      // Adjust hitbox size based on player height (head is higher than position)
      const playerHeadPosition = player.position.clone().add(new THREE.Vector3(0, 1.5, 0));
      const distanceToHead = bulletPosition.distanceTo(playerHeadPosition);
      
      // Check if bullet hit player body or head
      const bodyHitRadius = 0.7; // Body radius
      const headHitRadius = 0.4; // Head radius
      
      if (distance < bodyHitRadius || distanceToHead < headHitRadius) {
        // Trigger hit callback
        onHit(player.id, bullet.id);
      }
    });
  });
}

// Check if a position is inside a wall or other obstacle
export function checkWallCollision(
  position: THREE.Vector3,
  walls: { position: { x: number, y: number, z: number }, size: { width: number, height: number, depth: number } }[]
): boolean {
  // Add a small buffer to make collision detection more accurate
  const buffer = 0.3;
  
  // Check each wall
  for (const wall of walls) {
    // Expand the collision box slightly for better detection
    const wallMin = new THREE.Vector3(
      wall.position.x - wall.size.width / 2 - buffer,
      wall.position.y - wall.size.height / 2 - buffer,
      wall.position.z - wall.size.depth / 2 - buffer
    );
    
    const wallMax = new THREE.Vector3(
      wall.position.x + wall.size.width / 2 + buffer,
      wall.position.y + wall.size.height / 2 + buffer,
      wall.position.z + wall.size.depth / 2 + buffer
    );
    
    // Check if position is inside the wall's bounding box
    if (
      position.x >= wallMin.x && position.x <= wallMax.x &&
      position.y >= wallMin.y && position.y <= wallMax.y &&
      position.z >= wallMin.z && position.z <= wallMax.z
    ) {
      return true; // Collision detected
    }
  }
  
  return false; // No collision
}

// Ray cast to check line of sight between two points
export function hasLineOfSight(
  from: THREE.Vector3,
  to: THREE.Vector3,
  walls: { position: { x: number, y: number, z: number }, size: { width: number, height: number, depth: number } }[]
): boolean {
  // Direction vector
  const direction = to.clone().sub(from).normalize();
  
  // Distance between the points
  const distance = from.distanceTo(to);
  
  // Create a ray
  const ray = new THREE.Ray(from, direction);
  
  // Check intersection with each wall
  for (const wall of walls) {
    // Create wall bounding box
    const wallBox = new THREE.Box3(
      new THREE.Vector3(
        wall.position.x - wall.size.width / 2,
        wall.position.y - wall.size.height / 2,
        wall.position.z - wall.size.depth / 2
      ),
      new THREE.Vector3(
        wall.position.x + wall.size.width / 2,
        wall.position.y + wall.size.height / 2,
        wall.position.z + wall.size.depth / 2
      )
    );
    
    // Check for intersection
    const intersectionPoint = new THREE.Vector3();
    if (ray.intersectBox(wallBox, intersectionPoint)) {
      // Check if intersection is between from and to
      const intersectionDistance = from.distanceTo(intersectionPoint);
      if (intersectionDistance < distance) {
        return false; // Vision is blocked
      }
    }
  }
  
  return true; // No obstruction found
}
