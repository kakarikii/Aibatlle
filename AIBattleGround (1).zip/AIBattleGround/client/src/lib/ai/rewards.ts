import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { Agent } from "./agent";
import { GAME_CONSTANTS } from "../game/constants";

/**
 * Calculate reward for AI agent based on its actions and the game state
 */
export function calculateReward(
  agent: Agent,
  action: string,
  gameState: ReturnType<typeof useGameState.getState>,
  roundState: ReturnType<typeof useRoundState.getState>
): number {
  let reward = 0;
  
  // Find the current player associated with this agent
  const player = gameState.players.find(p => p.id === agent.id);
  if (!player || !player.isAlive) {
    return -10; // Dead players get negative reward
  }
  
  // Base rewards for different actions
  switch (action) {
    case 'combat':
      // Check if enemies are nearby - reward for engaging when appropriate
      if (agent.state.nearestEnemyDistance < 15) {
        reward += 5;
      } else {
        reward -= 2; // Penalty for seeking combat when no enemies are around
      }
      break;
      
    case 'plant_bomb':
      // Reward for attempting to plant when on a bombsite
      if (agent.team === 'T' && agent.state.hasBomb && 
          (agent.state.distanceToBombsiteA < 5 || agent.state.distanceToBombsiteB < 5)) {
        reward += 10;
        if (player.isPlanting) {
          reward += 5; // Extra reward for actually planting
        }
      } else {
        reward -= 5; // Penalty for trying to plant when not at a bombsite
      }
      break;
      
    case 'defuse_bomb':
      // Reward for attempting to defuse when bomb is planted
      if (agent.team === 'CT' && roundState.bombPlanted) {
        reward += 10;
        if (player.isDefusing) {
          reward += 5; // Extra reward for actually defusing
        }
      } else {
        reward -= 5; // Penalty for trying to defuse when no bomb is planted
      }
      break;
      
    case 'move_to_a':
    case 'move_to_b':
      // Reward for moving toward objectives
      if (agent.team === 'T' && !roundState.bombPlanted) {
        reward += 3; // Moving toward bombsites as T is good
      } else if (agent.team === 'CT' && roundState.bombPlanted) {
        reward += 3; // Moving toward bombsites as CT when bomb is planted is good
      } else if (agent.team === 'CT' && !roundState.bombPlanted) {
        reward += 1; // Defending bombsites as CT is good
      }
      break;
      
    case 'defend_bomb':
      // Reward for defending planted bomb
      if (agent.team === 'T' && roundState.bombPlanted) {
        reward += 5;
      } else {
        reward -= 2;
      }
      break;
      
    case 'defend_site':
      // Reward for defending bombsites as CT
      if (agent.team === 'CT' && !roundState.bombPlanted) {
        reward += 4;
      } else {
        reward -= 1;
      }
      break;
      
    case 'follow_teammate':
    case 'cover_teammate':
      // Reward for staying with team
      if (agent.state.nearestTeammateDistance < 10) {
        reward += 2;
      } else {
        reward += 1; // Still reward for trying to group up
      }
      break;
      
    case 'find_cover':
      // Reward for seeking cover when low on health
      if (player.health < 30) {
        reward += 4;
      } else {
        reward -= 1; // Penalty for hiding when healthy
      }
      break;
      
    case 'hold_position':
    case 'watch_flank':
    case 'patrol':
      // Reward for performing role-appropriate actions
      reward += 1;
      break;
      
    default:
      reward += 0; // Neutral reward for other actions
  }
  
  // Additional rewards based on game state
  
  // Team win/loss rewards
  if (roundState.roundState === 'ended') {
    if (
      (agent.team === 'T' && roundState.winningTeam === 'T') ||
      (agent.team === 'CT' && roundState.winningTeam === 'CT')
    ) {
      reward += 20; // Big reward for winning
    } else {
      reward -= 10; // Penalty for losing
    }
  }
  
  // Time-based rewards
  if (agent.team === 'T' && !roundState.bombPlanted && roundState.roundTimer < 30) {
    reward -= 3; // Penalty for running out of time without planting
  }
  
  // Strategic position rewards
  if (agent.role === 'sniper' && agent.state.nearestEnemyDistance > 20) {
    reward += 2; // Reward snipers for keeping distance
  }
  
  // Return the total calculated reward
  return reward;
}
