import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { mapData } from "../game/mapData";
import { GAME_CONSTANTS } from "../game/constants";
import { checkWallCollision, hasLineOfSight } from "../physics/collision";

/**
 * Execute an action for an AI agent - Improved implementation
 */
export function performAction(
  playerId: string,
  action: string,
  gameState: ReturnType<typeof useGameState.getState>
) {
  const player = gameState.players.find(p => p.id === playerId);
  if (!player || !player.isAlive) return;
  
  const roundState = useRoundState.getState();
  const walls = mapData.walls;
  
  // Get current player position and rotation
  const position = player.position.clone();
  let rotation = player.rotation;
  
  // Movement speed - increased for more dynamic gameplay
  const moveSpeed = 0.8;  // Much faster movement
  const shootDistance = 25; // Increased shooting range
  
  // Choose a random target if none exists
  let targetPosition = null;
  
  // Calculate movement based on action
  switch (action) {
    case 'combat':
      // Find nearest enemy and move toward them or shoot
      const nearestEnemy = findNearestEnemy(player, gameState.players);
      if (nearestEnemy) {
        const directionToEnemy = calculateDirectionTowards(position, nearestEnemy.position);
        rotation = Math.atan2(directionToEnemy.x, directionToEnemy.z);
        
        // Check if we have line of sight to the enemy before shooting
        const canSeeEnemy = hasLineOfSight(position, nearestEnemy.position, walls);
        
        // Shoot more frequently, but only if we can see the enemy
        if (canSeeEnemy && Math.random() < 0.3) {
          gameState.shoot(playerId, directionToEnemy);
        }
        
        // If enemy is within shooting range and visible, shoot and strafe
        if (position.distanceTo(nearestEnemy.position) < shootDistance && canSeeEnemy) {
          gameState.shoot(playerId, directionToEnemy);
          
          // Try to strafe a bit
          const strafeDir = Math.random() > 0.5 ? 1 : -1;
          const strafeVec = new THREE.Vector3(directionToEnemy.z * strafeDir, 0, -directionToEnemy.x * strafeDir);
          const strafePos = position.clone().add(strafeVec.multiplyScalar(0.4));
          
          // Only move if there's no wall collision
          if (!checkWallCollision(strafePos, walls)) {
            position.copy(strafePos);
          }
        } else {
          // Move toward enemy, even if we can't see them (we know their approximate location)
          const movePos = position.clone().add(directionToEnemy.multiplyScalar(moveSpeed));
          if (!checkWallCollision(movePos, walls)) {
            position.copy(movePos);
          } else {
            // Try to find a path around the wall
            const alternateDir = new THREE.Vector3(
              directionToEnemy.z,
              0,
              -directionToEnemy.x
            ).normalize();
            
            const altPos = position.clone().add(alternateDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(altPos, walls)) {
              position.copy(altPos);
            }
          }
        }
      } else {
        // No enemies visible, patrol
        const patrolRadiusX = 10 + Math.random() * 10;
        const patrolRadiusZ = 10 + Math.random() * 10;
        const time = Date.now() / 1000;
        
        position.x += Math.sin(time) * 0.2;
        position.z += Math.cos(time) * 0.2;
        rotation = Math.atan2(Math.sin(time), Math.cos(time));
      }
      break;
      
    case 'move_to_a':
      // Move toward bombsite A
      const bombsiteA = mapData.bombSites.find(site => site.name === 'A');
      if (bombsiteA) {
        const sitePosition = new THREE.Vector3(bombsiteA.position.x, 0, bombsiteA.position.z);
        const directionToA = calculateDirectionTowards(position, sitePosition);
        rotation = Math.atan2(directionToA.x, directionToA.z);
        
        // Shoot occasionally while moving
        if (Math.random() < 0.1) {
          gameState.shoot(playerId, directionToA);
        }
        
        const moveToAPos = position.clone().add(directionToA.multiplyScalar(moveSpeed));
        if (!checkWallCollision(moveToAPos, walls)) {
          position.copy(moveToAPos);
        } else {
          // Try to navigate around walls
          const alternateDir = new THREE.Vector3(
            directionToA.z,
            0,
            -directionToA.x
          ).normalize();
          
          // Try both left and right directions
          let foundPath = false;
          for (const multiplier of [1, -1]) {
            const testDir = alternateDir.clone().multiplyScalar(multiplier);
            const altPos = position.clone().add(testDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(altPos, walls)) {
              position.copy(altPos);
              foundPath = true;
              break;
            }
          }
          
          // If still stuck, try a random direction
          if (!foundPath) {
            const randomDir = new THREE.Vector3(
              Math.random() * 2 - 1,
              0,
              Math.random() * 2 - 1
            ).normalize();
            
            const randomPos = position.clone().add(randomDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(randomPos, walls)) {
              position.copy(randomPos);
            }
          }
        }
      }
      break;
      
    case 'move_to_b':
      // Move toward bombsite B with the same improvements as move_to_a
      const bombsiteB = mapData.bombSites.find(site => site.name === 'B');
      if (bombsiteB) {
        const sitePosition = new THREE.Vector3(bombsiteB.position.x, 0, bombsiteB.position.z);
        const directionToB = calculateDirectionTowards(position, sitePosition);
        rotation = Math.atan2(directionToB.x, directionToB.z);
        
        // Shoot occasionally while moving
        if (Math.random() < 0.1) {
          gameState.shoot(playerId, directionToB);
        }
        
        const moveToBPos = position.clone().add(directionToB.multiplyScalar(moveSpeed));
        if (!checkWallCollision(moveToBPos, walls)) {
          position.copy(moveToBPos);
        } else {
          // Try to navigate around walls with improved pathfinding
          const alternateDir = new THREE.Vector3(
            directionToB.z,
            0,
            -directionToB.x
          ).normalize();
          
          // Try both left and right directions
          let foundPath = false;
          for (const multiplier of [1, -1]) {
            const testDir = alternateDir.clone().multiplyScalar(multiplier);
            const altPos = position.clone().add(testDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(altPos, walls)) {
              position.copy(altPos);
              foundPath = true;
              break;
            }
          }
          
          // If still stuck, try a random direction
          if (!foundPath) {
            const randomDir = new THREE.Vector3(
              Math.random() * 2 - 1,
              0,
              Math.random() * 2 - 1
            ).normalize();
            
            const randomPos = position.clone().add(randomDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(randomPos, walls)) {
              position.copy(randomPos);
            }
          }
        }
      }
      break;
      
    case 'plant_bomb':
      // If we're a terrorist, prioritize getting to a bombsite and planting
      if (player.team === 'T') {
        const bombsites = mapData.bombSites;
        let closestSite = null;
        let minDistance = Infinity;
        
        // Find the closest bombsite
        for (const site of bombsites) {
          const sitePos = new THREE.Vector3(site.position.x, 0, site.position.z);
          const distance = position.distanceTo(sitePos);
          
          if (distance < minDistance) {
            minDistance = distance;
            closestSite = site;
          }
        }
        
        // If we're at a bombsite, plant the bomb
        if (closestSite && minDistance < 5) {
          // Player is at a bombsite, plant the bomb
          gameState.updatePlayer(playerId, { isPlanting: true });
          
          // After a delay, set the bomb as planted
          setTimeout(() => {
            const currentRoundState = useRoundState.getState();
            if (!currentRoundState.bombPlanted) {
              currentRoundState.setBombPlanted(true);
              gameState.updatePlayer(playerId, { isPlanting: false });
              console.log(`Bomb planted at ${closestSite.name} by ${playerId}`);
            }
          }, 3000); // 3 second plant time
        } else if (closestSite) {
          // Not at a bombsite yet, move toward the closest one
          const sitePos = new THREE.Vector3(closestSite.position.x, 0, closestSite.position.z);
          const dirToSite = calculateDirectionTowards(position, sitePos);
          rotation = Math.atan2(dirToSite.x, dirToSite.z);
          
          // Move faster toward bombsite when trying to plant
          const plantMovementSpeed = moveSpeed * 1.5;
          const moveToSitePos = position.clone().add(dirToSite.multiplyScalar(plantMovementSpeed));
          
          if (!checkWallCollision(moveToSitePos, walls)) {
            position.copy(moveToSitePos);
          } else {
            // Try to navigate around obstacles
            let foundPath = false;
            for (const angle of [Math.PI/4, -Math.PI/4, Math.PI/2, -Math.PI/2]) {
              const rotatedDir = new THREE.Vector3(
                Math.cos(angle) * dirToSite.x - Math.sin(angle) * dirToSite.z,
                0,
                Math.sin(angle) * dirToSite.x + Math.cos(angle) * dirToSite.z
              ).normalize();
              
              const altPos = position.clone().add(rotatedDir.multiplyScalar(plantMovementSpeed));
              if (!checkWallCollision(altPos, walls)) {
                position.copy(altPos);
                foundPath = true;
                break;
              }
            }
            
            // If still stuck, try random movement
            if (!foundPath) {
              const randomAngle = Math.random() * Math.PI * 2;
              const randomDir = new THREE.Vector3(
                Math.cos(randomAngle),
                0,
                Math.sin(randomAngle)
              ).normalize();
              
              const randomPos = position.clone().add(randomDir.multiplyScalar(moveSpeed));
              if (!checkWallCollision(randomPos, walls)) {
                position.copy(randomPos);
              }
            }
          }
        }
      }
      break;
            
    case 'patrol':
      // Dynamic patrol pattern
      const angle = Date.now() * 0.001 % (2 * Math.PI);
      const patrolX = Math.cos(angle) * (5 + Math.random() * 5);
      const patrolZ = Math.sin(angle) * (5 + Math.random() * 5);
      
      const targetPos = new THREE.Vector3(
        position.x + patrolX,
        position.y,
        position.z + patrolZ
      );
      
      const dirToTarget = calculateDirectionTowards(position, targetPos);
      rotation = Math.atan2(dirToTarget.x, dirToTarget.z);
      
      // Only shoot if we can see an enemy
      const visibleEnemyWhilePatrolling = findNearestEnemy(player, gameState.players);
      if (visibleEnemyWhilePatrolling && 
          hasLineOfSight(position, visibleEnemyWhilePatrolling.position, walls) &&
          Math.random() < 0.1) {
        const dirToVisibleEnemy = calculateDirectionTowards(position, visibleEnemyWhilePatrolling.position);
        gameState.shoot(playerId, dirToVisibleEnemy);
      }
      
      const movePos = position.clone().add(dirToTarget.multiplyScalar(moveSpeed * 0.5));
      if (!checkWallCollision(movePos, walls)) {
        position.copy(movePos);
      }
      break;
      
    case 'rush_site':
      // Rush to a random bombsite
      const site = Math.random() < 0.5 ? 'A' : 'B';
      const targetSite = mapData.bombSites.find(s => s.name === site);
      
      if (targetSite) {
        const sitePos = new THREE.Vector3(targetSite.position.x, 0, targetSite.position.z);
        const dirToSite = calculateDirectionTowards(position, sitePos);
        rotation = Math.atan2(dirToSite.x, dirToSite.z);
        
        // Check for enemies in line of sight while rushing
        const nearestVisibleEnemy = findNearestEnemy(player, gameState.players);
        if (nearestVisibleEnemy && hasLineOfSight(position, nearestVisibleEnemy.position, walls)) {
          // If enemy spotted, shoot at them instead of random firing
          const dirToEnemy = calculateDirectionTowards(position, nearestVisibleEnemy.position);
          rotation = Math.atan2(dirToEnemy.x, dirToEnemy.z);
          
          if (Math.random() < 0.25) {
            gameState.shoot(playerId, dirToEnemy);
          }
        } else {
          // Only shoot occasionally if no enemy in sight
          if (Math.random() < 0.05) {
            gameState.shoot(playerId, dirToSite);
          }
        }
        
        // Move faster when rushing
        const rushPos = position.clone().add(dirToSite.multiplyScalar(moveSpeed * 1.2));
        if (!checkWallCollision(rushPos, walls)) {
          position.copy(rushPos);
        } else {
          // Try alternate paths (improved pathfinding)
          // Try multiple directions when hitting a wall
          let foundPath = false;
          for (const angle of [Math.PI/4, -Math.PI/4, Math.PI/2, -Math.PI/2]) {
            // Rotate direction vector by angle
            const rotatedDir = new THREE.Vector3(
              Math.cos(angle) * dirToSite.x - Math.sin(angle) * dirToSite.z,
              0,
              Math.sin(angle) * dirToSite.x + Math.cos(angle) * dirToSite.z
            ).normalize();
            
            const altPos = position.clone().add(rotatedDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(altPos, walls)) {
              position.copy(altPos);
              foundPath = true;
              break;
            }
          }
          
          // If still stuck, try a more random direction
          if (!foundPath) {
            const randomDir = new THREE.Vector3(
              Math.random() * 2 - 1,
              0,
              Math.random() * 2 - 1
            ).normalize();
            
            const randomPos = position.clone().add(randomDir.multiplyScalar(moveSpeed * 0.5));
            if (!checkWallCollision(randomPos, walls)) {
              position.copy(randomPos);
            }
          }
        }
      }
      break;
      
    case 'hold_position':
      // Stay in place but look around and shoot
      rotation = (rotation + 0.03) % (2 * Math.PI);
      
      // Shoot more frequently when holding position
      if (Math.random() < 0.1) {
        const shootDir = new THREE.Vector3(Math.cos(rotation), 0, Math.sin(rotation));
        gameState.shoot(playerId, shootDir);
      }
      
      // Small movement to avoid being perfectly still
      const smallMove = new THREE.Vector3(
        (Math.random() - 0.5) * 0.2,
        0,
        (Math.random() - 0.5) * 0.2
      );
      
      const slightMovePos = position.clone().add(smallMove);
      if (!checkWallCollision(slightMovePos, walls)) {
        position.copy(slightMovePos);
      }
      break;
      
    default:
      // For any other actions, use varied movement
      const randomAngle = Math.random() * Math.PI * 2;
      const randomDir = new THREE.Vector3(
        Math.cos(randomAngle),
        0,
        Math.sin(randomAngle)
      );
      
      rotation = Math.atan2(randomDir.x, randomDir.z);
      
      // Occasionally shoot
      if (Math.random() < 0.05) {
        gameState.shoot(playerId, randomDir);
      }
      
      const randomMovePos = position.clone().add(randomDir.multiplyScalar(moveSpeed * 0.5));
      if (!checkWallCollision(randomMovePos, walls)) {
        position.copy(randomMovePos);
      }
      break;
  }
  
  // Keep player within map bounds
  position.x = Math.max(-40, Math.min(40, position.x));
  position.z = Math.max(-40, Math.min(40, position.z));
  position.y = 1; // Keep player at the correct height
  
  // Update player position and rotation
  gameState.movePlayer(playerId, position, rotation);
}

// Helper function to find nearest enemy
function findNearestEnemy(player: any, players: any[]) {
  let nearestEnemy = null;
  let minDistance = Infinity;
  
  players.forEach(otherPlayer => {
    if (otherPlayer.team !== player.team && otherPlayer.isAlive) {
      const distance = player.position.distanceTo(otherPlayer.position);
      if (distance < minDistance) {
        minDistance = distance;
        nearestEnemy = otherPlayer;
      }
    }
  });
  
  return nearestEnemy;
}

// Helper function to find nearest teammate
function findNearestTeammate(player: any, players: any[]) {
  let nearestTeammate = null;
  let minDistance = Infinity;
  
  players.forEach(otherPlayer => {
    if (otherPlayer.id !== player.id && otherPlayer.team === player.team && otherPlayer.isAlive) {
      const distance = player.position.distanceTo(otherPlayer.position);
      if (distance < minDistance) {
        minDistance = distance;
        nearestTeammate = otherPlayer;
      }
    }
  });
  
  return nearestTeammate;
}

// Helper function to find nearest wall
function findNearestWall(position: THREE.Vector3, walls: any[]) {
  let nearestWall = null;
  let minDistance = Infinity;
  
  walls.forEach(wall => {
    const wallPosition = new THREE.Vector3(wall.position.x, 0, wall.position.z);
    const distance = position.distanceTo(wallPosition);
    if (distance < minDistance) {
      minDistance = distance;
      nearestWall = wall;
    }
  });
  
  return nearestWall;
}

// Helper function to calculate direction toward a target
function calculateDirectionTowards(from: THREE.Vector3, to: THREE.Vector3) {
  const direction = to.clone().sub(from).normalize();
  direction.y = 0; // Keep movement on the same plane
  return direction;
}

// Helper function to check if position is within an area
function isPositionWithinArea(position: THREE.Vector3, area: any) {
  const halfWidth = area.size.width / 2;
  const halfDepth = area.size.depth / 2;
  
  return (
    position.x >= area.position.x - halfWidth &&
    position.x <= area.position.x + halfWidth &&
    position.z >= area.position.z - halfDepth &&
    position.z <= area.position.z + halfDepth
  );
}