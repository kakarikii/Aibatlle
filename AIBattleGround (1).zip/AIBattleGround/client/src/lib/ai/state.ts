import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { mapData } from "../game/mapData";
import { AgentState } from "./agent";

/**
 * Extract the current state for an AI agent from the game state
 */
export function getAgentState(
  player: any,
  allPlayers: any[],
  roundState: ReturnType<typeof useRoundState.getState>
): AgentState {
  // Get bombsites
  const bombsiteA = mapData.bombSites.find(site => site.name === 'A');
  const bombsiteB = mapData.bombSites.find(site => site.name === 'B');
  
  // Calculate distances to bombsites
  const distanceToBombsiteA = bombsiteA 
    ? player.position.distanceTo(new THREE.Vector3(bombsiteA.position.x, 0, bombsiteA.position.z))
    : 100;
    
  const distanceToBombsiteB = bombsiteB
    ? player.position.distanceTo(new THREE.Vector3(bombsiteB.position.x, 0, bombsiteB.position.z))
    : 100;
  
  // Find nearest enemy and teammate
  let nearestEnemyDistance = 100;
  let nearestTeammateDistance = 100;
  
  allPlayers.forEach(otherPlayer => {
    if (!otherPlayer.isAlive) return;
    
    const distance = player.position.distanceTo(otherPlayer.position);
    
    if (otherPlayer.id !== player.id) {
      if (otherPlayer.team !== player.team) {
        // Enemy
        nearestEnemyDistance = Math.min(nearestEnemyDistance, distance);
      } else {
        // Teammate
        nearestTeammateDistance = Math.min(nearestTeammateDistance, distance);
      }
    }
  });
  
  // Check if player has bomb (for T)
  // In this simplified version, we'll just say the first T player has the bomb
  const hasBomb = player.team === 'T' && player.id === 't-0';
  
  return {
    position: player.position.clone(),
    health: player.health,
    isAlive: player.isAlive,
    nearestEnemyDistance,
    nearestTeammateDistance,
    distanceToBombsiteA,
    distanceToBombsiteB,
    hasBomb,
    bombPlanted: roundState.bombPlanted,
    roundTimeRemaining: roundState.roundTimer
  };
}
