import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { mapData } from "../game/mapData";
import { GAME_CONSTANTS } from "../game/constants";
import { checkWallCollision } from "../physics/collision";

/**
 * Execute an action for an AI agent
 */
export function performAction(
  playerId: string,
  action: string,
  gameState: ReturnType<typeof useGameState.getState>
) {
  const walls = mapData.walls;
  const player = gameState.players.find(p => p.id === playerId);
  if (!player || !player.isAlive) return;
  
  const roundState = useRoundState.getState();
  
  // Get current player position and rotation
  const position = player.position.clone();
  let rotation = player.rotation;
  
  // Movement speed - increased for more dynamic gameplay
  const moveSpeed = 0.4;  // Faster movement
  const shootDistance = 20; // Increased shooting range
  
  // Calculate movement based on action
  switch (action) {
    case 'combat':
      // Find nearest enemy and move toward them or shoot
      const nearestEnemy = findNearestEnemy(player, gameState.players);
      if (nearestEnemy) {
        const directionToEnemy = calculateDirectionTowards(position, nearestEnemy.position);
        rotation = Math.atan2(directionToEnemy.x, directionToEnemy.z);
        
        // If enemy is within shooting range, shoot
        if (position.distanceTo(nearestEnemy.position) < shootDistance) {
          gameState.shoot(playerId, directionToEnemy);
          
          // Try to strafe a bit
          const strafeDir = Math.random() > 0.5 ? 1 : -1;
          const strafeVec = new THREE.Vector3(directionToEnemy.z * strafeDir, 0, -directionToEnemy.x * strafeDir);
          const newPos = position.clone().add(strafeVec.multiplyScalar(0.2));
          
          // Only move if there's no wall collision
          if (!checkWallCollision(newPos, walls)) {
            position.copy(newPos);
          }
        } else {
          // Move toward enemy
          const newPos = position.clone().add(directionToEnemy.multiplyScalar(moveSpeed));
          if (!checkWallCollision(newPos, walls)) {
            position.copy(newPos);
          } else {
            // Try to find a path around the wall
            const alternateDir = new THREE.Vector3(
              directionToEnemy.z,
              0,
              -directionToEnemy.x
            ).normalize();
            
            const altPos = position.clone().add(alternateDir.multiplyScalar(moveSpeed));
            if (!checkWallCollision(altPos, walls)) {
              position.copy(altPos);
            }
          }
        }
      }
      break;
      
    case 'move_to_a':
      // Move toward bombsite A
      const bombsiteA = mapData.bombSites.find(site => site.name === 'A');
      if (bombsiteA) {
        const sitePosition = new THREE.Vector3(bombsiteA.position.x, 0, bombsiteA.position.z);
        const directionToA = calculateDirectionTowards(position, sitePosition);
        rotation = Math.atan2(directionToA.x, directionToA.z);
        
        const newPos = position.clone().add(directionToA.multiplyScalar(moveSpeed));
        if (!checkWallCollision(newPos, walls)) {
          position.copy(newPos);
        } else {
          // Try to navigate around walls
          const alternateDir = new THREE.Vector3(
            directionToA.z,
            0,
            -directionToA.x
          ).normalize();
          
          const altPos = position.clone().add(alternateDir.multiplyScalar(moveSpeed));
          if (!checkWallCollision(altPos, walls)) {
            position.copy(altPos);
          }
        }
      }
      break;
      
    case 'move_to_b':
      // Move toward bombsite B
      const bombsiteB = mapData.bombSites.find(site => site.name === 'B');
      if (bombsiteB) {
        const sitePosition = new THREE.Vector3(bombsiteB.position.x, 0, bombsiteB.position.z);
        const directionToB = calculateDirectionTowards(position, sitePosition);
        rotation = Math.atan2(directionToB.x, directionToB.z);
        
        const newPos = position.clone().add(directionToB.multiplyScalar(moveSpeed));
        if (!checkWallCollision(newPos, walls)) {
          position.copy(newPos);
        } else {
          // Try to navigate around walls
          const alternateDir = new THREE.Vector3(
            directionToB.z,
            0,
            -directionToB.x
          ).normalize();
          
          const altPos = position.clone().add(alternateDir.multiplyScalar(moveSpeed));
          if (!checkWallCollision(altPos, walls)) {
            position.copy(altPos);
          }
        }
      }
      break;
      
    case 'plant_bomb':
      // Try to plant the bomb if at a bombsite
      if (player.team === 'T') {
        const bombsiteA = mapData.bombSites.find(site => site.name === 'A');
        const bombsiteB = mapData.bombSites.find(site => site.name === 'B');
        
        if (bombsiteA && isPositionWithinArea(position, bombsiteA)) {
          // Start planting at A
          gameState.updatePlayer(playerId, { isPlanting: true });
          
          // Simulate planting time
          setTimeout(() => {
            // If player is still alive and planting
            const updatedPlayer = gameState.players.find(p => p.id === playerId);
            if (updatedPlayer && updatedPlayer.isAlive && updatedPlayer.isPlanting) {
              // Set bomb as planted
              useRoundState.getState().setBombPlanted(true);
              gameState.updatePlayer(playerId, { isPlanting: false });
            }
          }, 3000);
        } else if (bombsiteB && isPositionWithinArea(position, bombsiteB)) {
          // Start planting at B
          gameState.updatePlayer(playerId, { isPlanting: true });
          
          // Simulate planting time
          setTimeout(() => {
            // If player is still alive and planting
            const updatedPlayer = gameState.players.find(p => p.id === playerId);
            if (updatedPlayer && updatedPlayer.isAlive && updatedPlayer.isPlanting) {
              // Set bomb as planted
              useRoundState.getState().setBombPlanted(true);
              gameState.updatePlayer(playerId, { isPlanting: false });
            }
          }, 3000);
        } else {
          // Not at bombsite, move to one
          const bombsiteToUse = Math.random() > 0.5 ? bombsiteA : bombsiteB;
          if (bombsiteToUse) {
            const sitePosition = new THREE.Vector3(bombsiteToUse.position.x, 0, bombsiteToUse.position.z);
            const directionToSite = calculateDirectionTowards(position, sitePosition);
            rotation = Math.atan2(directionToSite.x, directionToSite.z);
            
            const newPos = position.clone().add(directionToSite.multiplyScalar(moveSpeed));
            if (!checkWallCollision(newPos, walls)) {
              position.copy(newPos);
            }
          }
        }
      }
      break;
      
    case 'defuse_bomb':
      // Try to defuse the bomb
      if (player.team === 'CT' && roundState.bombPlanted) {
        // Find active bombsite - simplified by assuming it's at (0,0)
        const bombPosition = new THREE.Vector3(0, 0, 0);
        
        // If close to bomb, start defusing
        if (position.distanceTo(bombPosition) < 5) {
          // Start defusing
          gameState.updatePlayer(playerId, { isDefusing: true });
          
          // Simulate defusing time
          setTimeout(() => {
            // If player is still alive and defusing
            const updatedPlayer = gameState.players.find(p => p.id === playerId);
            if (updatedPlayer && updatedPlayer.isAlive && updatedPlayer.isDefusing) {
              // Set bomb as defused
              useRoundState.getState().setBombDefused(true);
              gameState.updatePlayer(playerId, { isDefusing: false });
            }
          }, 5000);
        } else {
          // Move toward bomb position
          const directionToBomb = calculateDirectionTowards(position, bombPosition);
          rotation = Math.atan2(directionToBomb.x, directionToBomb.z);
          
          const newPos = position.clone().add(directionToBomb.multiplyScalar(moveSpeed));
          if (!checkWallCollision(newPos, walls)) {
            position.copy(newPos);
          }
        }
      }
      break;
      
    case 'follow_teammate':
      // Find nearest teammate and follow them
      const nearestTeammate = findNearestTeammate(player, gameState.players);
      if (nearestTeammate) {
        const directionToTeammate = calculateDirectionTowards(position, nearestTeammate.position);
        rotation = Math.atan2(directionToTeammate.x, directionToTeammate.z);
        
        // Only move if not too close to avoid clustering
        if (position.distanceTo(nearestTeammate.position) > 3) {
          const newPos = position.clone().add(directionToTeammate.multiplyScalar(moveSpeed));
          if (!checkWallCollision(newPos, walls)) {
            position.copy(newPos);
          }
        }
      }
      break;
      
    case 'defend_bomb':
      // Stay near the planted bomb
      if (roundState.bombPlanted) {
        // Determine which bombsite the bomb is planted at
        const bombsiteA = mapData.bombSites.find(site => site.name === 'A');
        const bombsiteB = mapData.bombSites.find(site => site.name === 'B');
        
        // Simple logic - just assume bombsite A for now (in a real game we'd track this properly)
        const bombPosition = bombsiteA 
          ? new THREE.Vector3(bombsiteA.position.x, 0, bombsiteA.position.z)
          : new THREE.Vector3(0, 0, 0);
          
        const directionToBomb = calculateDirectionTowards(position, bombPosition);
        
        // If too far from bomb, move closer
        if (position.distanceTo(bombPosition) > 10) {
          rotation = Math.atan2(directionToBomb.x, directionToBomb.z);
          
          const newPos = position.clone().add(directionToBomb.multiplyScalar(moveSpeed));
          if (!checkWallCollision(newPos, walls)) {
            position.copy(newPos);
          }
        }
        
        // Look for enemies
        const nearestEnemyForDefense = findNearestEnemy(player, gameState.players);
        if (nearestEnemyForDefense && position.distanceTo(bombPosition) < 15) {
          const directionToEnemy = calculateDirectionTowards(position, nearestEnemyForDefense.position);
          rotation = Math.atan2(directionToEnemy.x, directionToEnemy.z);
          
          // Shoot if enemy is visible
          if (position.distanceTo(nearestEnemyForDefense.position) < shootDistance) {
            gameState.shoot(playerId, directionToEnemy);
          }
        }
      }
      break;
      
    case 'patrol':
      // Patrol between random points
      // For simplicity, just move in a circular pattern
      // Patrol between random points using simple circular movement
      const patrolRadius = 10;
      const patrolSpeed = 0.05;
      const time = Date.now() / 1000;
      
      const targetX = Math.cos(time * patrolSpeed) * patrolRadius;
      const targetZ = Math.sin(time * patrolSpeed) * patrolRadius;
      
      const targetPosition = new THREE.Vector3(targetX, 0, targetZ);
      const directionToTarget = calculateDirectionTowards(position, targetPosition);
      rotation = Math.atan2(directionToTarget.x, directionToTarget.z);
      
      // Try to move toward target position
      const newPos = position.clone().add(directionToTarget.multiplyScalar(moveSpeed));
      if (!checkWallCollision(newPos, walls)) {
        position.copy(newPos);
      }
      break;
      
    case 'hold_position':
      // Stay in place and look around
      rotation = (rotation + 0.01) % (2 * Math.PI);
      
      // Occasionally shoot to simulate watching for enemies
      if (Math.random() < 0.03) {
        const randomDirection = new THREE.Vector3(
          Math.cos(rotation),
          0,
          Math.sin(rotation)
        );
        gameState.shoot(playerId, randomDirection);
      }
      break;
      
    case 'find_cover':
      // Move toward nearest wall or cover
      const nearestWall = findNearestWall(position, walls);
      if (nearestWall) {
        const wallPosition = new THREE.Vector3(
          nearestWall.position.x,
          0,
          nearestWall.position.z
        );
        const directionToWall = calculateDirectionTowards(position, wallPosition);
        rotation = Math.atan2(directionToWall.x, directionToWall.z);
        
        const newPos = position.clone().add(directionToWall.multiplyScalar(moveSpeed));
        if (!checkWallCollision(newPos, walls)) {
          position.copy(newPos);
        }
      }
      break;
      
    default:
      // Default behavior - move in a small random direction
      const randomDirection = new THREE.Vector3(
        (Math.random() - 0.5) * 0.1,
        0,
        (Math.random() - 0.5) * 0.1
      );
      const newPos = position.clone().add(randomDirection);
      if (!checkWallCollision(newPos, walls)) {
        position.copy(newPos);
      }
      rotation = Math.atan2(randomDirection.x, randomDirection.z);
      break;
  }
  
  // Keep player within map bounds
  position.x = Math.max(-50, Math.min(50, position.x));
  position.z = Math.max(-50, Math.min(50, position.z));
  position.y = 1; // Keep player at the correct height
  
  // Update player position and rotation
  gameState.movePlayer(playerId, position, rotation);
}

// Helper function to find nearest enemy
function findNearestEnemy(player: any, players: any[]) {
  let nearestEnemy = null;
  let minDistance = Infinity;
  
  players.forEach(otherPlayer => {
    if (otherPlayer.team !== player.team && otherPlayer.isAlive) {
      const distance = player.position.distanceTo(otherPlayer.position);
      if (distance < minDistance) {
        minDistance = distance;
        nearestEnemy = otherPlayer;
      }
    }
  });
  
  return nearestEnemy;
}

// Helper function to find nearest teammate
function findNearestTeammate(player: any, players: any[]) {
  let nearestTeammate = null;
  let minDistance = Infinity;
  
  players.forEach(otherPlayer => {
    if (otherPlayer.id !== player.id && otherPlayer.team === player.team && otherPlayer.isAlive) {
      const distance = player.position.distanceTo(otherPlayer.position);
      if (distance < minDistance) {
        minDistance = distance;
        nearestTeammate = otherPlayer;
      }
    }
  });
  
  return nearestTeammate;
}

// Helper function to find nearest wall
function findNearestWall(position: THREE.Vector3, walls: any[]) {
  let nearestWall = null;
  let minDistance = Infinity;
  
  walls.forEach(wall => {
    const wallPosition = new THREE.Vector3(wall.position.x, 0, wall.position.z);
    const distance = position.distanceTo(wallPosition);
    if (distance < minDistance) {
      minDistance = distance;
      nearestWall = wall;
    }
  });
  
  return nearestWall;
}

// Helper function to calculate direction toward a target
function calculateDirectionTowards(from: THREE.Vector3, to: THREE.Vector3) {
  const direction = to.clone().sub(from).normalize();
  direction.y = 0; // Keep movement on the same plane
  return direction;
}

// Helper function to check if position is within an area
function isPositionWithinArea(position: THREE.Vector3, area: any) {
  const halfWidth = area.size.width / 2;
  const halfDepth = area.size.depth / 2;
  
  return (
    position.x >= area.position.x - halfWidth &&
    position.x <= area.position.x + halfWidth &&
    position.z >= area.position.z - halfDepth &&
    position.z <= area.position.z + halfDepth
  );
}
