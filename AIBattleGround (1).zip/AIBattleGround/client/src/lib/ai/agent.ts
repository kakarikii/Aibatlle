import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { calculateReward } from "./rewards";
import { performAction } from "./simplified-actions";
import { getAgentState } from "./state";
import { GAME_CONSTANTS } from "../game/constants";
import { mapData } from "../game/mapData";

// Simplified AI agent implementation
// In a real implementation, we would use TensorFlow.js or similar for ML

// Agent configuration
export interface Agent {
  id: string;
  team: 'T' | 'CT';
  state: AgentState;
  learning: boolean;
  rewardHistory: number[];
  targetPosition?: THREE.Vector3;
  nextActionTime: number;
  role: 'rusher' | 'support' | 'lurker' | 'sniper' | 'leader';
}

// Agent state
export interface AgentState {
  position: THREE.Vector3;
  health: number;
  isAlive: boolean;
  nearestEnemyDistance: number;
  nearestTeammateDistance: number;
  distanceToBombsiteA: number;
  distanceToBombsiteB: number;
  hasBomb: boolean;
  bombPlanted: boolean;
  roundTimeRemaining: number;
}

// Store AI agents
const agents: Agent[] = [];

// Create AI agents based on players
export function setupAIAgents() {
  const { players } = useGameState.getState();
  
  // Clear existing agents
  agents.length = 0;
  
  // Create agents for each player
  players.forEach((player, index) => {
    const roles = ['rusher', 'support', 'lurker', 'sniper', 'leader'];
    const role = roles[index % roles.length] as Agent['role'];
    
    agents.push({
      id: player.id,
      team: player.team,
      state: {
        position: player.position.clone(),
        health: player.health,
        isAlive: player.isAlive,
        nearestEnemyDistance: 100,
        nearestTeammateDistance: 100,
        distanceToBombsiteA: 100,
        distanceToBombsiteB: 100,
        hasBomb: player.team === 'T' && index === 0, // First T player has bomb
        bombPlanted: false,
        roundTimeRemaining: 120
      },
      learning: true,
      rewardHistory: [],
      nextActionTime: 0,
      role
    });
  });
  
  console.log("AI Agents initialized:", agents.length);
}

// Update AI agents
export function updateAIAgents(deltaTime: number) {
  const gameState = useGameState.getState();
  const roundState = useRoundState.getState();
  
  // Don't update AI if round is not active
  if (roundState.roundState !== 'active') {
    return;
  }
  
  // Process each agent
  agents.forEach(agent => {
    // Find the corresponding player
    const player = gameState.players.find(p => p.id === agent.id);
    
    if (!player || !player.isAlive) {
      return;
    }
    
    // Update agent state
    agent.state = getAgentState(player, gameState.players, roundState);
    
    // Only take action periodically (simulated thinking time)
    const currentTime = Date.now();
    if (currentTime < agent.nextActionTime) {
      return;
    }
    
    // Determine action interval based on role - faster timing for more active gameplay
    const thinkTime = getThinkTimeForRole(agent.role);
    agent.nextActionTime = currentTime + thinkTime;
    
    // Decide on an action based on role and state
    const action = decideAction(agent);
    
    // Execute the action
    performAction(player.id, action, gameState);
    
    // Calculate reward for this action
    const reward = calculateReward(agent, action, gameState, roundState);
    agent.rewardHistory.push(reward);
  });
}

// Get think time based on agent role - make it even faster for more visible movement
function getThinkTimeForRole(role: Agent['role']): number {
  switch (role) {
    case 'rusher': return 100; // Extremely fast reactions
    case 'sniper': return 200; // Faster aiming
    case 'leader': return 150; // Quick coordinating
    case 'lurker': return 120; // Quick flanking
    case 'support': return 150; // Quick support
    default: return 150; // Faster default reaction time
  }
}

// Improved role-based decision making with more varied and aggressive actions
function decideAction(agent: Agent): string {
  const { team, state, role } = agent;
  
  // Add some randomness to create more dynamic behavior (20% chance)
  if (Math.random() < 0.2) {
    // Choose a random aggressive action
    const randomActions = ['combat', 'rush_site', 'move_to_a', 'move_to_b', 'patrol'];
    return randomActions[Math.floor(Math.random() * randomActions.length)];
  }
  
  // If health is critical, prioritize finding cover or combat (more balanced)
  if (state.health < 30) {
    return Math.random() < 0.3 ? 'combat' : 'find_cover';
  }
  
  // Team-specific strategies
  if (team === 'T') {
    // Terrorist logic
    if (state.bombPlanted) {
      // Mix up defend bomb with combat for more dynamic behavior
      return Math.random() < 0.6 ? 'defend_bomb' : 'combat';
    }
    
    if (state.hasBomb) {
      // Bomb carrier logic - much higher priority on planting
      
      // If we're near a bombsite, prioritize planting
      if (state.distanceToBombsiteA < 8 || state.distanceToBombsiteB < 8) {
        return 'plant_bomb'; // Very high priority on planting when at a site
      } else if (state.nearestEnemyDistance < 15) {
        return Math.random() < 0.4 ? 'combat' : 'find_cover'; // Better survival chances
      } else if (state.roundTimeRemaining < 50) {
        // Late in round - rush to nearest site to plant
        return state.distanceToBombsiteA < state.distanceToBombsiteB ? 
          'move_to_a' : 'move_to_b';
      } else if (Math.random() < 0.1) {
        // Occasionally try to plant - higher chance 
        return 'plant_bomb';
      } else {
        // Choose closest bombsite and move there directly
        return state.distanceToBombsiteA < state.distanceToBombsiteB ? 
          'move_to_a' : 'move_to_b';
      }
    } else {
      // Non-bomb carrier logic based on role - more aggressive and varied
      switch(role) {
        case 'rusher': 
          // Rushers should be very aggressive
          return (state.nearestEnemyDistance < 20 || Math.random() < 0.7) ? 'combat' : 'rush_site';
        case 'support':
          // Support should mix between helping teammates and taking initiative
          return Math.random() < 0.3 ? 'follow_teammate' : 
                 (Math.random() < 0.5 ? 'move_to_a' : 'move_to_b');
        case 'lurker':
          // Lurkers should alternate between flanking and fighting
          return Math.random() < 0.6 ? 'flank_enemies' : 'combat';
        case 'sniper':
          // Snipers take shots but should move sometimes
          return Math.random() < 0.3 ? 'move_to_a' : 
                 (Math.random() < 0.5 ? 'hold_position' : 'combat');
        case 'leader':
          // Leaders should push sites and combat
          return Math.random() < 0.4 ? 'combat' : 
                 (Math.random() < 0.5 ? 'move_to_a' : 'move_to_b');
      }
    }
  } else {
    // Counter-Terrorist logic - more aggressive defense
    if (state.bombPlanted) {
      // Balance between fighting and defusing
      if (state.nearestEnemyDistance < 15) {
        return 'combat'; // Clear enemies first
      } else {
        return 'defuse_bomb';
      }
    }
    
    // Role-based CT behavior - more active
    switch(role) {
      case 'rusher':
        // CT rushers should actively hunt
        return Math.random() < 0.7 ? 'combat' : 'patrol';
      case 'support':
        // Support should move between sites
        return Math.random() < 0.4 ? 'defend_site' : 
               (Math.random() < 0.5 ? 'move_to_a' : 'move_to_b');
      case 'lurker':
        // Lurkers should be more active
        return Math.random() < 0.5 ? 'combat' : 'watch_flank';
      case 'sniper':
        // Snipers should reposition
        return Math.random() < 0.3 ? 'patrol' : 
               (Math.random() < 0.6 ? 'hold_position' : 'combat');
      case 'leader':
        // Leaders should coordinate site defense
        return Math.random() < 0.4 ? 'combat' : 
               (Math.random() < 0.5 ? 'defend_site' : 'patrol');
    }
  }
  
  // Default actions with more variety
  const defaultActions = ['patrol', 'combat', 'move_to_a', 'move_to_b'];
  return defaultActions[Math.floor(Math.random() * defaultActions.length)];
}
