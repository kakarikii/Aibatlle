import { create } from "zustand";
import * as THREE from "three";

// Player type
export interface Player {
  id: string;
  position: THREE.Vector3;
  rotation: number;
  health: number;
  team: 'T' | 'CT';
  weapon: string;
  isAI: boolean;
  isAlive: boolean;
  isDefusing: boolean;
  isPlanting: boolean;
}

// Bullet type
export interface Bullet {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  weapon: string;
}

// Game state interface
interface GameState {
  // State
  players: Player[];
  bullets: Bullet[];
  
  // Player actions
  addPlayer: (player: Player) => void;
  updatePlayer: (id: string, updates: Partial<Omit<Player, 'id'>>) => void;
  removePlayer: (id: string) => void;
  movePlayer: (id: string, newPosition: THREE.Vector3, newRotation: number) => void;
  
  // Bullet actions
  addBullet: (bullet: Bullet) => void;
  updateBullet: (id: string, updates: Partial<Omit<Bullet, 'id'>>) => void;
  removeBullet: (id: string) => void;
  
  // Shooting
  shoot: (playerId: string, direction: THREE.Vector3) => void;
  
  // Reset game
  resetGameState: () => void;
}

export const useGameState = create<GameState>((set, get) => ({
  // Initial state
  players: [],
  bullets: [],
  
  // Player methods
  addPlayer: (player) => set(state => ({ 
    players: [...state.players, player] 
  })),
  
  updatePlayer: (id, updates) => set(state => ({
    players: state.players.map(player => 
      player.id === id ? { ...player, ...updates } : player
    )
  })),
  
  removePlayer: (id) => set(state => ({
    players: state.players.filter(player => player.id !== id)
  })),
  
  movePlayer: (id, newPosition, newRotation) => set(state => ({
    players: state.players.map(player => 
      player.id === id ? { 
        ...player, 
        position: newPosition, 
        rotation: newRotation 
      } : player
    )
  })),
  
  // Bullet methods
  addBullet: (bullet) => set(state => ({
    bullets: [...state.bullets, bullet]
  })),
  
  updateBullet: (id, updates) => set(state => ({
    bullets: state.bullets.map(bullet => 
      bullet.id === id ? { ...bullet, ...updates } : bullet
    )
  })),
  
  removeBullet: (id) => set(state => ({
    bullets: state.bullets.filter(bullet => bullet.id !== id)
  })),
  
  // Shooting action
  shoot: (playerId, direction) => {
    const { players } = get();
    const player = players.find(p => p.id === playerId);
    
    if (player && player.isAlive) {
      // Create a normalized direction vector
      const normalizedDirection = direction.clone().normalize();
      
      // Create bullet position slightly in front of the player
      const bulletPosition = player.position.clone().add(
        normalizedDirection.clone().multiplyScalar(1.5).setY(1.5)
      );
      
      // Add bullet to state
      get().addBullet({
        id: `bullet-${playerId}-${Date.now()}`,
        position: bulletPosition,
        velocity: normalizedDirection.clone().multiplyScalar(1), // Adjust speed as needed
        weapon: player.weapon
      });
    }
  },
  
  // Reset game state
  resetGameState: () => set({
    players: [],
    bullets: []
  })
}));
