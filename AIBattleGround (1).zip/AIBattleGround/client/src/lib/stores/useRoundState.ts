import { create } from "zustand";

// Round state types
export type RoundState = 'warmup' | 'active' | 'ended';
export type WinningTeam = 'T' | 'CT' | null;

interface RoundStateStore {
  // State
  roundState: RoundState;
  roundNumber: number;
  roundTimer: number;
  bombTimer: number;
  bombPlanted: boolean;
  bombDefused: boolean;
  tWins: number;
  ctWins: number;
  winningTeam: WinningTeam;
  
  // Actions
  startNewRound: () => void;
  endRound: (winningTeam: 'T' | 'CT') => void;
  setRoundTimer: (time: number) => void;
  setBombTimer: (time: number) => void;
  setBombPlanted: (planted: boolean) => void;
  setBombDefused: (defused: boolean) => void;
  incrementTWins: () => void;
  incrementCTWins: () => void;
  resetRoundState: () => void;
}

export const useRoundState = create<RoundStateStore>((set) => ({
  // Initial state
  roundState: 'warmup',
  roundNumber: 0,
  roundTimer: 120, // 2 minutes per round
  bombTimer: 40, // 40 seconds for bomb timer
  bombPlanted: false,
  bombDefused: false,
  tWins: 0,
  ctWins: 0,
  winningTeam: null,
  
  // Start a new round
  startNewRound: () => set(state => {
    // If we reached 30 rounds total, reset the game
    if (state.roundNumber >= 30) {
      return {
        ...state,
        roundState: 'warmup',
        roundNumber: 1,
        roundTimer: 120,
        bombPlanted: false,
        bombDefused: false,
        tWins: 0,
        ctWins: 0,
        winningTeam: null
      };
    }
    
    // Otherwise increment round number and set active
    return {
      ...state,
      roundState: 'active',
      roundNumber: state.roundNumber + 1,
      roundTimer: 120,
      bombPlanted: false,
      bombDefused: false,
      winningTeam: null
    };
  }),
  
  // End the current round
  endRound: (winningTeam) => set(state => {
    if (state.roundState !== 'ended') {
      console.log(`Round ended. Winner: ${winningTeam}`);
      return {
        ...state,
        roundState: 'ended',
        winningTeam
      };
    }
    return state;
  }),
  
  // Set round timer
  setRoundTimer: (time) => set({ roundTimer: time }),
  
  // Set bomb timer
  setBombTimer: (time) => set({ bombTimer: time }),
  
  // Set bomb planted
  setBombPlanted: (planted) => set({ bombPlanted: planted }),
  
  // Set bomb defused
  setBombDefused: (defused) => set({ bombDefused: defused }),
  
  // Increment T wins
  incrementTWins: () => set(state => ({ tWins: state.tWins + 1 })),
  
  // Increment CT wins
  incrementCTWins: () => set(state => ({ ctWins: state.ctWins + 1 })),
  
  // Reset round state
  resetRoundState: () => set({
    roundState: 'warmup',
    roundNumber: 0,
    roundTimer: 120,
    bombTimer: 40,
    bombPlanted: false,
    bombDefused: false,
    tWins: 0,
    ctWins: 0,
    winningTeam: null
  })
}));
