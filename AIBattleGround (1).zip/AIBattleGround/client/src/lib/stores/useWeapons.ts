import { create } from "zustand";

// Weapon types
export type WeaponType = 'pistol' | 'rifle' | 'sniper';

// Weapon data
export interface WeaponData {
  type: WeaponType;
  name: string;
  damage: number;
  fireRate: number; // Rounds per second
  accuracy: number; // 0-1 scale
  range: number;
  cost: number;
}

// Store interface
interface WeaponStore {
  // Weapon catalog
  weapons: Record<string, WeaponData>;
  
  // Methods
  getWeaponByType: (type: WeaponType) => WeaponData;
  getWeaponDamage: (weaponType: WeaponType, distance: number, isHeadshot: boolean) => number;
}

export const useWeapons = create<WeaponStore>((set, get) => ({
  // Define available weapons
  weapons: {
    glock: {
      type: 'pistol',
      name: 'Glock-18',
      damage: 25,
      fireRate: 2,
      accuracy: 0.7,
      range: 20,
      cost: 200
    },
    usp: {
      type: 'pistol',
      name: 'USP-S',
      damage: 30,
      fireRate: 1.5,
      accuracy: 0.8,
      range: 25,
      cost: 200
    },
    ak47: {
      type: 'rifle',
      name: 'AK-47',
      damage: 35,
      fireRate: 10,
      accuracy: 0.75,
      range: 50,
      cost: 2700
    },
    m4a4: {
      type: 'rifle',
      name: 'M4A4',
      damage: 30,
      fireRate: 11,
      accuracy: 0.8,
      range: 45,
      cost: 3100
    },
    awp: {
      type: 'sniper',
      name: 'AWP',
      damage: 115,
      fireRate: 0.7,
      accuracy: 0.95,
      range: 100,
      cost: 4750
    }
  },
  
  // Get a default weapon by type
  getWeaponByType: (type) => {
    const { weapons } = get();
    
    // Return the first weapon of the requested type
    const weaponKey = Object.keys(weapons).find(key => weapons[key].type === type);
    return weaponKey ? weapons[weaponKey] : weapons['glock']; // Default to glock if not found
  },
  
  // Calculate damage based on weapon, distance and hit location
  getWeaponDamage: (weaponType, distance, isHeadshot) => {
    const { getWeaponByType } = get();
    const weapon = getWeaponByType(weaponType);
    
    // Calculate damage falloff based on distance
    let damage = weapon.damage;
    const falloffStart = weapon.range * 0.5;
    
    if (distance > falloffStart) {
      const falloffFactor = Math.max(0, 1 - ((distance - falloffStart) / (weapon.range - falloffStart)));
      damage *= falloffFactor;
    }
    
    // Apply headshot multiplier
    if (isHeadshot) {
      damage *= weaponType === 'sniper' ? 1.5 : 4; // AWP already does high damage
    }
    
    return Math.round(damage);
  }
}));
