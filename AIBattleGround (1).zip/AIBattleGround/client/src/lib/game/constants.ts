// Game constants for CS simulation

export const GAME_CONSTANTS = {
  // Player settings
  PLAYER: {
    MOVE_SPEED: 5,
    ROTATE_SPEED: 2,
    MAX_HEALTH: 100,
    RESPAWN_TIME: 5
  },
  
  // Weapon settings
  WEAPONS: {
    RIFLE: {
      DAMAGE: 25,
      FIRE_RATE: 10, // rounds per second
      RELOAD_TIME: 2.5, // seconds
      MAGAZINE_SIZE: 30,
      ACCURACY: 0.9
    },
    PISTOL: {
      DAMAGE: 15,
      FIRE_RATE: 5,
      RELOAD_TIME: 1.5,
      MAGAZINE_SIZE: 12,
      ACCURACY: 0.8
    },
    SNIPER: {
      DAMAGE: 100,
      FIRE_RATE: 1,
      RELOAD_TIME: 3.5,
      MAGAZINE_SIZE: 10,
      ACCURACY: 0.98
    }
  },
  
  // Round settings
  ROUND: {
    DURATION: 120, // 2 minutes
    BOMB_TIMER: 40, // 40 seconds
    PLANT_TIME: 3, // 3 seconds to plant
    DEFUSE_TIME: 5, // 5 seconds to defuse
    MAX_ROUNDS: 30,
    ROUND_WIN_MONEY_CT: 3250,
    ROUND_WIN_MONEY_T: 3500,
    ROUND_LOSS_MIN: 1400,
    ROUND_LOSS_MAX: 3500
  },
  
  // Economy settings
  ECONOMY: {
    STARTING_MONEY: 800,
    MAX_MONEY: 16000,
    KILL_REWARD: 300
  },
  
  // AI settings
  AI: {
    REACTION_TIME_MIN: 0.2, // seconds
    REACTION_TIME_MAX: 0.8,
    DECISION_INTERVAL: 0.5, // how often AI makes decisions
    SIGHT_RANGE: 30, // how far AI can "see"
    FOV: 120 // field of view in degrees
  },
  
  // Physics settings
  PHYSICS: {
    GRAVITY: 9.8,
    BULLET_SPEED: 70,
    BULLET_MAX_DISTANCE: 100,
    BULLET_LIFETIME: 3 // seconds
  }
};
