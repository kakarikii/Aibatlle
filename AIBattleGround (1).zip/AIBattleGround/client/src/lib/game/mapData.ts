// Map data for Dust2 layout - Closed version

export const mapData = {
  // Walls and structures
  walls: [
    // Outer walls - completely enclosed map with taller walls
    // North wall
    {
      position: { x: 0, y: 3, z: -40 },
      size: { width: 80, height: 8, depth: 1 }
    },
    // South wall
    {
      position: { x: 0, y: 3, z: 40 },
      size: { width: 80, height: 8, depth: 1 }
    },
    // East wall
    {
      position: { x: 40, y: 3, z: 0 },
      size: { width: 1, height: 8, depth: 80 }
    },
    // West wall
    {
      position: { x: -40, y: 3, z: 0 },
      size: { width: 1, height: 8, depth: 80 }
    },
    
    // T Spawn area - with taller walls
    {
      position: { x: -30, y: 3, z: -35 },
      size: { width: 15, height: 6, depth: 1 }
    },
    {
      position: { x: -35, y: 3, z: -30 },
      size: { width: 1, height: 6, depth: 10 }
    },
    
    // T Spawn to Lower Tunnels - narrower corridors with taller walls
    {
      position: { x: -25, y: 3, z: -25 },
      size: { width: 2, height: 6, depth: 15 }
    },
    {
      position: { x: -15, y: 3, z: -25 },
      size: { width: 2, height: 6, depth: 10 }
    },
    
    // Lower Tunnels - thicker and taller walls
    {
      position: { x: -15, y: 3, z: -10 },
      size: { width: 20, height: 6, depth: 2 }
    },
    
    // Upper Tunnels to B - narrower passage with taller walls
    {
      position: { x: -30, y: 3, z: -5 },
      size: { width: 2, height: 6, depth: 10 }
    },
    {
      position: { x: -20, y: 3, z: 0 },
      size: { width: 15, height: 6, depth: 2 }
    },
    
    // Bombsite B outer walls - much taller
    {
      position: { x: -25, y: 4, z: 5 },
      size: { width: 15, height: 8, depth: 2 }
    },
    {
      position: { x: -32, y: 4, z: 10 },
      size: { width: 2, height: 8, depth: 15 }
    },
    {
      position: { x: -25, y: 4, z: 15 },
      size: { width: 15, height: 8, depth: 2 }
    },
    
    // B Site Plat - larger for better cover
    {
      position: { x: -28, y: 1, z: 10 },
      size: { width: 6, height: 2, depth: 6 }
    },
    
    // Extra boxes at B site
    {
      position: { x: -22, y: 1, z: 7 },
      size: { width: 3, height: 2, depth: 3 }
    },
    {
      position: { x: -18, y: 1, z: 12 },
      size: { width: 3, height: 1.5, depth: 3 }
    },
    
    // Mid doors - narrower passage
    {
      position: { x: -5, y: 1.5, z: 0 },
      size: { width: 2, height: 3, depth: 8 }
    },
    {
      position: { x: 5, y: 1.5, z: 0 },
      size: { width: 2, height: 3, depth: 8 }
    },
    
    // Mid to B connector - more enclosed
    {
      position: { x: -10, y: 1.5, z: 8 },
      size: { width: 10, height: 3, depth: 2 }
    },
    {
      position: { x: -15, y: 1.5, z: 3 },
      size: { width: 2, height: 3, depth: 10 }
    },
    
    // Mid to A - Catwalk - narrower passage
    {
      position: { x: 15, y: 1.5, z: 0 },
      size: { width: 2, height: 3, depth: 15 }
    },
    {
      position: { x: 10, y: 1.5, z: 8 },
      size: { width: 10, height: 3, depth: 2 }
    },
    
    // Long A - enclosed corridor
    {
      position: { x: 0, y: 1.5, z: -15 },
      size: { width: 30, height: 3, depth: 2 }
    },
    {
      position: { x: 15, y: 1.5, z: -10 },
      size: { width: 2, height: 3, depth: 10 }
    },
    {
      position: { x: 25, y: 1.5, z: -20 },
      size: { width: 2, height: 3, depth: 10 }
    },
    {
      position: { x: 15, y: 1.5, z: -20 },
      size: { width: 20, height: 3, depth: 2 }
    },
    
    // A Site - much taller walls
    {
      position: { x: 30, y: 4, z: -5 },
      size: { width: 15, height: 8, depth: 2 }
    },
    {
      position: { x: 35, y: 4, z: 0 },
      size: { width: 2, height: 8, depth: 10 }
    },
    {
      position: { x: 30, y: 4, z: 5 },
      size: { width: 15, height: 8, depth: 2 }
    },
    {
      position: { x: 25, y: 4, z: 0 },
      size: { width: 2, height: 8, depth: 10 }
    },
    
    // A Site boxes - more cover
    {
      position: { x: 32, y: 1, z: 0 },
      size: { width: 4, height: 2, depth: 4 }
    },
    {
      position: { x: 28, y: 1, z: 2 },
      size: { width: 4, height: 2, depth: 4 }
    },
    {
      position: { x: 33, y: 1, z: -3 },
      size: { width: 3, height: 1, depth: 3 }
    },
    
    // CT Spawn area - enclosed
    {
      position: { x: 0, y: 1.5, z: 30 },
      size: { width: 40, height: 3, depth: 2 }
    },
    {
      position: { x: 20, y: 1.5, z: 25 },
      size: { width: 2, height: 3, depth: 10 }
    },
    
    // B to CT path - narrower corridors
    {
      position: { x: -15, y: 1.5, z: 20 },
      size: { width: 2, height: 3, depth: 15 }
    },
    {
      position: { x: -5, y: 1.5, z: 25 },
      size: { width: 20, height: 3, depth: 2 }
    },
    
    // A to CT path - enclosed
    {
      position: { x: 15, y: 1.5, z: 15 },
      size: { width: 20, height: 3, depth: 2 }
    },
    {
      position: { x: 12, y: 1.5, z: 20 },
      size: { width: 2, height: 3, depth: 10 }
    },
    
    // Pit at Long A
    {
      position: { x: 20, y: 0, z: -25 },
      size: { width: 10, height: 1, depth: 5 }
    },
    
    // Car at B 
    {
      position: { x: -20, y: 1, z: 10 },
      size: { width: 3, height: 1.5, depth: 5 }
    },
    
    // Additional obstacles for more cover
    // Mid barriers
    {
      position: { x: 0, y: 1, z: 0 },
      size: { width: 6, height: 2, depth: 1 }
    },
    {
      position: { x: 0, y: 1, z: -5 },
      size: { width: 1, height: 2, depth: 6 }
    },
    
    // T spawn cover
    {
      position: { x: -30, y: 1, z: -30 },
      size: { width: 5, height: 2, depth: 5 }
    },
    
    // CT spawn cover
    {
      position: { x: 10, y: 1, z: 25 },
      size: { width: 5, height: 2, depth: 5 }
    }
  ],
  
  // Bomb sites
  bombSites: [
    {
      name: 'A',
      position: { x: 30, y: 0, z: 0 },
      size: { width: 12, height: 0, depth: 12 }
    },
    {
      name: 'B',
      position: { x: -25, y: 0, z: 10 },
      size: { width: 12, height: 0, depth: 12 }
    }
  ],
  
  // Team spawn points
  spawnPoints: [
    // T spawn points
    {
      team: 'T',
      position: { x: -30, y: 0, z: -30 }
    },
    {
      team: 'T',
      position: { x: -27, y: 0, z: -32 }
    },
    {
      team: 'T',
      position: { x: -25, y: 0, z: -30 }
    },
    {
      team: 'T',
      position: { x: -28, y: 0, z: -28 }
    },
    {
      team: 'T',
      position: { x: -32, y: 0, z: -28 }
    },
    
    // CT spawn points
    {
      team: 'CT',
      position: { x: 10, y: 0, z: 28 }
    },
    {
      team: 'CT',
      position: { x: 7, y: 0, z: 25 }
    },
    {
      team: 'CT',
      position: { x: 12, y: 0, z: 25 }
    },
    {
      team: 'CT',
      position: { x: 5, y: 0, z: 28 }
    },
    {
      team: 'CT',
      position: { x: 15, y: 0, z: 28 }
    }
  ]
};
