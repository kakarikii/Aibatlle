import * as THREE from "three";
import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { GAME_CONSTANTS } from "./constants";

/**
 * Assign roles to team members
 */
export function assignTeamRoles(team: 'T' | 'CT') {
  const gameState = useGameState.getState();
  
  // Get all alive players in the team
  const teamPlayers = gameState.players.filter(p => p.team === team && p.isAlive);
  
  // If no players, do nothing
  if (teamPlayers.length === 0) {
    return;
  }
  
  // Define the different roles
  const roles = ['entry', 'support', 'lurk', 'awp', 'igl'];
  
  // Assign roles based on team
  if (team === 'T') {
    // T side strategies
    const strategies = [
      'rush_a',
      'rush_b',
      'split_a',
      'split_b',
      'default'
    ];
    
    // Pick a random strategy
    const strategy = strategies[Math.floor(Math.random() * strategies.length)];
    
    console.log(`T team selected strategy: ${strategy}`);
    
    // Simple role assignment
    teamPlayers.forEach((player, index) => {
      const role = roles[index % roles.length];
      
      // Set player's role
      // In a real implementation, we'd store this in the player state
      console.log(`Assigned ${player.id} to role: ${role}`);
    });
  } else {
    // CT side setups
    const setups = [
      'stack_a',
      'stack_b',
      'split_2a_3b',
      'split_3a_2b',
      'default'
    ];
    
    // Pick a random setup
    const setup = setups[Math.floor(Math.random() * setups.length)];
    
    console.log(`CT team selected setup: ${setup}`);
    
    // Simple role assignment
    teamPlayers.forEach((player, index) => {
      const role = roles[index % roles.length];
      
      // Set player's role
      // In a real implementation, we'd store this in the player state
      console.log(`Assigned ${player.id} to role: ${role}`);
    });
  }
}

/**
 * Coordinate team movements (simplified AI team tactics)
 */
export function coordinateTeamMovement(team: 'T' | 'CT', strategy: string) {
  const gameState = useGameState.getState();
  
  // Get all alive players in the team
  const teamPlayers = gameState.players.filter(p => p.team === team && p.isAlive);
  
  // Create a formation based on strategy
  let formationPositions: THREE.Vector3[] = [];
  
  // Define center point based on strategy
  let centerX = 0;
  let centerZ = 0;
  
  switch (strategy) {
    case 'rush_a':
      centerX = 20;
      centerZ = -15;
      break;
    case 'rush_b':
      centerX = -20;
      centerZ = -15;
      break;
    case 'split_a':
      // Two groups
      for (let i = 0; i < teamPlayers.length; i++) {
        if (i < Math.ceil(teamPlayers.length / 2)) {
          // First group goes one way
          formationPositions.push(new THREE.Vector3(20 + (i * 2), 1, -15));
        } else {
          // Second group goes another way
          formationPositions.push(new THREE.Vector3(20 - ((i - Math.floor(teamPlayers.length / 2)) * 2), 1, -15));
        }
      }
      return formationPositions;
    case 'split_b':
      // Two groups
      for (let i = 0; i < teamPlayers.length; i++) {
        if (i < Math.ceil(teamPlayers.length / 2)) {
          // First group goes one way
          formationPositions.push(new THREE.Vector3(-20 + (i * 2), 1, -15));
        } else {
          // Second group goes another way
          formationPositions.push(new THREE.Vector3(-20 - ((i - Math.floor(teamPlayers.length / 2)) * 2), 1, -15));
        }
      }
      return formationPositions;
    default:
      // Default formation
      centerX = team === 'T' ? 0 : 0;
      centerZ = team === 'T' ? -15 : 15;
      break;
  }
  
  // Create a simple line formation
  for (let i = 0; i < teamPlayers.length; i++) {
    formationPositions.push(new THREE.Vector3(
      centerX - (teamPlayers.length / 2) * 2 + i * 2,
      1,
      centerZ
    ));
  }
  
  return formationPositions;
}

/**
 * Check if the team should save weapons (economic decision)
 */
export function shouldTeamSave(team: 'T' | 'CT'): boolean {
  const gameState = useGameState.getState();
  const roundState = useRoundState.getState();
  
  // Get all alive players in the team
  const teamPlayers = gameState.players.filter(p => p.team === team && p.isAlive);
  const enemyPlayers = gameState.players.filter(p => p.team !== team && p.isAlive);
  
  // Check if we're heavily outnumbered
  if (teamPlayers.length < enemyPlayers.length / 2) {
    // If we're at a significant disadvantage, consider saving
    return true;
  }
  
  // If the bomb is planted, different logic applies
  if (roundState.bombPlanted) {
    if (team === 'T') {
      // T team with planted bomb should never save
      return false;
    } else {
      // CT team with planted bomb should save if heavily outnumbered
      return teamPlayers.length < enemyPlayers.length - 1;
    }
  }
  
  // Default behavior - don't save
  return false;
}
