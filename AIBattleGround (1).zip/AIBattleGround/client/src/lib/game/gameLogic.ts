import { useGameState } from "../stores/useGameState";
import { useRoundState } from "../stores/useRoundState";
import { generateRandomPosition } from "../physics/movement";
import { GAME_CONSTANTS } from "./constants";
import { mapData } from "./mapData";

/**
 * Setup a new round with initial positions and reset states
 */
export function setupNewRound() {
  const gameState = useGameState.getState();
  const roundState = useRoundState.getState();
  
  // Reset all players
  gameState.players.forEach(player => {
    // Generate spawn position based on team
    const spawnPosition = generateRandomPosition(player.team);
    
    // Reset player state
    gameState.updatePlayer(player.id, {
      position: spawnPosition,
      rotation: player.team === 'T' ? 0 : Math.PI, // T looking forward, CT looking backward
      health: 100,
      isAlive: true,
      isDefusing: false,
      isPlanting: false
    });
  });
  
  // Clear all bullets
  gameState.bullets.forEach(bullet => {
    gameState.removeBullet(bullet.id);
  });
  
  // Reset bomb state
  roundState.setBombPlanted(false);
  roundState.setBombDefused(false);
  
  // Set round timer
  roundState.setRoundTimer(GAME_CONSTANTS.ROUND.DURATION);
  
  console.log("New round setup completed");
}

/**
 * Check win conditions for the current round
 */
export function checkWinConditions() {
  const gameState = useGameState.getState();
  const roundState = useRoundState.getState();
  
  // Skip check if round is not active
  if (roundState.roundState !== 'active') {
    return null;
  }
  
  // Count alive players in each team
  const aliveTPlayers = gameState.players.filter(p => p.team === 'T' && p.isAlive).length;
  const aliveCTPlayers = gameState.players.filter(p => p.team === 'CT' && p.isAlive).length;
  
  // Check win conditions
  
  // Bomb exploded (T win)
  if (roundState.bombPlanted && roundState.bombTimer <= 0) {
    return 'T';
  }
  
  // Bomb defused (CT win)
  if (roundState.bombPlanted && roundState.bombDefused) {
    return 'CT';
  }
  
  // All Ts eliminated and bomb not planted (CT win)
  if (aliveTPlayers === 0 && !roundState.bombPlanted) {
    return 'CT';
  }
  
  // All CTs eliminated (T win)
  if (aliveCTPlayers === 0) {
    return 'T';
  }
  
  // Round timer expired without bomb plant (CT win)
  if (roundState.roundTimer <= 0 && !roundState.bombPlanted) {
    return 'CT';
  }
  
  // No win condition met yet
  return null;
}

/**
 * Process end of round logic
 */
export function endRound(winningTeam: 'T' | 'CT') {
  const roundState = useRoundState.getState();
  
  // End the round with the winning team
  roundState.endRound(winningTeam);
  
  // Update win counts
  if (winningTeam === 'T') {
    roundState.incrementTWins();
  } else {
    roundState.incrementCTWins();
  }
  
  console.log(`Round ended, winner: ${winningTeam}`);
}
