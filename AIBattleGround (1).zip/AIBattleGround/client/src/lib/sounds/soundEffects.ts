import { useAudio } from "../stores/useAudio";

// Sound effect types
type SoundEffectType = 'gunshot' | 'explosion' | 'hit' | 'plant' | 'defuse' | 'roundStart' | 'roundEnd' | 'lowAmmo';

// Sound manager for playing game sound effects
export function playSoundEffect(type: SoundEffectType, volume: number = 1.0) {
  const { isMuted, playHit, playSuccessSound } = useAudio.getState();
  
  // If audio is muted, don't play anything
  if (isMuted) {
    console.log(`Sound effect ${type} skipped (muted)`);
    return;
  }
  
  // Map sound effect type to the appropriate sound
  switch (type) {
    case 'gunshot':
      // Use the hit sound for gunshots
      playHit();
      break;
      
    case 'explosion':
    case 'roundEnd':
      // Use success sound for explosions
      playSuccessSound();
      break;
      
    case 'hit':
      playHit();
      break;
      
    case 'plant':
    case 'defuse':
    case 'roundStart':
    case 'lowAmmo':
      // These would use other sounds, but we'll use what we have
      playHit();
      break;
  }
}

// Play ambient sounds based on game state
export function playAmbientSounds(roundActive: boolean) {
  const { backgroundMusic, isMuted } = useAudio.getState();
  
  if (!backgroundMusic || isMuted) {
    return;
  }
  
  if (roundActive) {
    // Make sure background music is playing during active round
    if (backgroundMusic.paused) {
      backgroundMusic.currentTime = 0;
      backgroundMusic.play().catch(error => {
        console.warn("Background music play prevented:", error);
      });
    }
  } else {
    // Pause background music between rounds
    if (!backgroundMusic.paused) {
      backgroundMusic.pause();
    }
  }
}

// Play team-specific voice lines
export function playTeamVoiceLine(team: 'T' | 'CT', lineType: string) {
  const { isMuted, playHit } = useAudio.getState();
  
  if (isMuted) {
    return;
  }
  
  // Just use hit sound for voice lines since we don't have specific audio files
  playHit();
  
  console.log(`Team ${team} voice line: ${lineType}`);
}

// Play weapon sounds
export function playWeaponSound(weapon: string) {
  const { isMuted, playHit } = useAudio.getState();
  
  if (isMuted) {
    return;
  }
  
  // Just use hit sound for all weapons
  playHit();
  
  console.log(`Weapon sound: ${weapon}`);
}
