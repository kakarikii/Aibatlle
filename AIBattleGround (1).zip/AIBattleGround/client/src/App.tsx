import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import "@fontsource/inter";
import Arena from "./components/game/Arena";
import GameUI from "./components/game/GameUI";

// Define control keys for the game
enum Controls {
  forward = 'forward',
  backward = 'backward',
  leftward = 'leftward',
  rightward = 'rightward',
  shoot = 'shoot',
  plant = 'plant',
  defuse = 'defuse',
  reload = 'reload',
  switch1 = 'switch1',
  switch2 = 'switch2',
  switch3 = 'switch3',
}

const controls = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.leftward, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.rightward, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.shoot, keys: ["Mouse0"] },
  { name: Controls.plant, keys: ["KeyE"] },
  { name: Controls.defuse, keys: ["KeyE"] },
  { name: Controls.reload, keys: ["KeyR"] },
  { name: Controls.switch1, keys: ["Digit1"] },
  { name: Controls.switch2, keys: ["Digit2"] },
  { name: Controls.switch3, keys: ["Digit3"] },
];

// Main App component
function App() {
  const [showCanvas, setShowCanvas] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  // Load audio assets
  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hit = new Audio("/sounds/hit.mp3");
    setHitSound(hit);

    const success = new Audio("/sounds/success.mp3");
    setSuccessSound(success);

    console.log("Audio assets loaded");
    
    // Show the canvas once everything is loaded
    setShowCanvas(true);

    return () => {
      bgMusic.pause();
      bgMusic.currentTime = 0;
    };
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {showCanvas && (
        <KeyboardControls map={controls}>
          <Canvas
            shadows
            camera={{
              position: [0, 30, 30],
              fov: 50,
              near: 0.1,
              far: 1000
            }}
            gl={{
              antialias: true,
              powerPreference: "default"
            }}
          >
            <color attach="background" args={["#87CEEB"]} />
            
            {/* Main game arena with all game components */}
            <Suspense fallback={null}>
              <Arena />
            </Suspense>
          </Canvas>
          
          {/* Game UI overlay */}
          <GameUI />
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
